# 🟢 Sprint 8 — Entrega 3: Agent Presence

Sistema de presencia en vivo para agentes: heartbeat, detección de inactividad,
indicador visual en header, lista de equipo con estado real-time.

---

## 📦 Archivos incluidos (5)

| Ruta | Tipo | Descripción |
|---|---|---|
| `src/stores/agent.store.ts` | 🆕 Nuevo | Store del agente logueado (mi status) |
| `src/composables/usePresence.ts` | 🆕 Nuevo | Heartbeat + detección de inactividad |
| `src/components/AgentStatusBadge.vue` | 🆕 Nuevo | Badge + dropdown de cambio manual |
| `src/layouts/AdminLayout.vue` | 🔧 Reemplazar | Agregado badge + activado usePresence |
| `src/modules/agents/views/AgentsView.vue` | 🔧 Reemplazar | Lista de equipo con estado en vivo |

---

## 🚀 Aplicación

### Paso 1: Copiar los 5 archivos

Todos vienen con ruta completa desde `/src`.

### Paso 2: Build

```powershell
npm run build
```

Debe pasar sin errores. Si aparece algún TS error, pégamelo.

### Paso 3: Dev

```powershell
npm run dev
```

### Paso 4: Probar

#### Test A — Badge de estado aparece en el header

1. Login (como cualquier usuario)
2. Debes ver en el header, al lado del nombre, un badge pequeño tipo:
   `🟢 En línea ▼`
3. A los ~5 segundos (tiempo que tarda el primer heartbeat), si entró como offline, debe cambiar a "En línea"

#### Test B — Cambiar estado manualmente

1. Click en el badge
2. Se abre un dropdown con 4 opciones: En línea, Ocupado, Ausente, Desconectado
3. Selecciona "Ocupado"
4. Toast verde: "Estado cambiado a ocupado"
5. El badge ahora se ve amarillo: `🟡 Ocupado ▼`

#### Test C — Vista de Equipo

1. Ir a `/admin/agents` (Equipo en el sidebar)
2. Ves las tarjetas de los 3 usuarios (tú + 2 admins)
3. Tú debes aparecer con tu estado actual
4. Los otros 2 admins deben aparecer como "Desconectado" (nunca han hecho heartbeat)
5. Stats arriba: "3 miembros · 1 en línea"

#### Test D — Filtros en Equipo

1. Click en tab "En línea" → solo te ves tú
2. Click en "Desconectados" → los otros 2 admins
3. Click en "Todos" → los 3

#### Test E — Realtime entre ventanas

1. Abre la app en 2 ventanas/pestañas distintas (misma cuenta)
2. En una, cambia estado a "Ocupado"
3. En la otra ventana, **sin recargar**, el badge del header cambia a Ocupado
4. También cambia en la vista de Equipo

#### Test F — Detector de inactividad (opcional, toma 5 min)

1. Login, verifica que estás "En línea"
2. **No muevas mouse ni toques teclado** por 5 minutos
3. Al minuto 5, automáticamente cambia a "Ausente" 🟡→⚪
4. Mueve el mouse
5. En el siguiente heartbeat (≤60s), vuelve a "En línea"

#### Test G — Heartbeat automático

1. Abre DevTools → Network → filtra por "rpc"
2. Cada 60 segundos ves una petición a `agent_heartbeat`
3. Status 200 en cada una

#### Test H — Cerrar sesión marca offline

1. Click "Salir"
2. Antes de redirigir a login, se dispara el `markOffline`
3. Abre otra ventana con otra cuenta y ve a `/admin/agents`
4. Tu cuenta aparece como "Desconectado" ⚫

---

## 🎯 Qué hace el sistema

### Heartbeat cada 60s
Cuando el agente está activo (mouse/teclado), cada minuto envía un ping que:
- Actualiza `last_activity_at` en DB
- Si estaba `away` → vuelve a `online` automático

### Detector de inactividad (5 min)
Si pasan 5 minutos sin **ningún** evento de:
- `mousemove`, `mousedown`
- `keydown`
- `touchstart`
- `scroll`

Entonces automáticamente cambia el estado a `away`.

### Cambio manual
El agente puede forzar un estado cualquier momento con el dropdown. Ese estado se mantiene mientras siga activo. Si no hay heartbeat en 5 min, igual pasa a `away`.

### Cleanup al cerrar
- `beforeunload` (cerrar ventana) → marca `offline`
- Logout → marca `offline`
- Desmonte del layout → marca `offline`

Si el navegador se cierra bruscamente sin alcanzar a mandar el offline, el cron `agents_auto_away` lo pondrá en `away` eventualmente (cuando lo implementemos como cron automático).

---

## 🎨 Visualización

### Colores por estado
- 🟢 **En línea** — `#10b981` (verde)
- 🟡 **Ocupado** — `#f59e0b` (ámbar)
- ⚪ **Ausente** — `#94a3b8` (gris claro)
- ⚫ **Desconectado** — `#64748b` (gris oscuro)

### Dónde aparece
- Header (lado derecho, al lado del nombre)
- En cada tarjeta de agente en `/admin/agents` (dot en el avatar)

---

## ⚠️ Limitaciones conocidas

### 1. El auto_away NO corre automáticamente server-side
Si un agente cierra el navegador sin marcar offline, sigue mostrándose "online" para otros hasta que:
- Vuelva a abrir la app (donde el composable lo actualiza)
- Alguien llame manualmente `agents_auto_away(5)`

**Solución futura:** scheduled cron en Supabase que corra `agents_auto_away()` cada 1 min. Ampliable en Entrega 4.

### 2. Status message (mensaje custom)
La DB soporta `status_message` pero la UI aún no tiene input para escribirlo. Se puede agregar en la Entrega 4 (Workspace completo).

### 3. El super_admin en modo soporte
El heartbeat se envía siempre contra **tu** user_id, no contra el tenant. Esto es correcto: tu status es global, no por tenant.

---

## 💾 Commit sugerido

```bash
git add -A
git commit -m "feat(sprint-8-entrega3): Agent Presence con heartbeat y realtime

- Store agent.store.ts: mi propio status global
- Composable usePresence: heartbeat 60s + detector inactividad 5min
- Componente AgentStatusBadge: badge + dropdown cambio manual
- AdminLayout: integracion badge en header + activacion usePresence
- AgentsView: lista agentes con estado live + realtime + filtros

Eventos que trigger actividad:
  mousemove, mousedown, keydown, touchstart, scroll
Cleanup al desmontar + beforeunload: marca offline."
```

---

## 🎯 Siguiente: Entrega 4 — Agent Workspace (2h)

- Quick Replies CRUD (shortcuts con /)
- Inserción de snippets en ConversationThread
- Panel lateral con historial completo del contacto en Inbox
- Detalle del agente (métricas, skills, config)
- Scheduled cron de `agents_auto_away`

---

## 🐛 Troubleshooting

### Error en build: "Cannot find module '@/stores/agent.store'"
El store es nuevo, verifica que se copió bien a `src/stores/agent.store.ts`.

### Badge no aparece en el header
1. Ver consola para errores
2. Verifica que `AgentStatusBadge` se importó en `AdminLayout.vue`
3. Verifica que `authStore.user` tiene data (no `null`)

### Heartbeat falla con "not found"
La RPC `agent_heartbeat` no existe en Supabase. Vuelve a correr la migración de Entrega 1.

### "No aparezco en la vista de Equipo"
Verifica con SQL: `SELECT COUNT(*) FROM agents WHERE user_id = 'tu-user-id';`
Si da 0, tu registro en `agents` no se creó. Corre el hotfix del backfill:
```sql
INSERT INTO agents (user_id, organization_id, status)
SELECT id, organization_id, 'offline' FROM users
WHERE NOT EXISTS (SELECT 1 FROM agents a WHERE a.user_id = users.id);
```

### El realtime no funciona entre pestañas
Verifica que Supabase Realtime esté habilitado para la tabla `agents`:
Dashboard → Database → Replication → marca `agents` como enabled.
