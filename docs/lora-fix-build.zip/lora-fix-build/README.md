# 🔧 Fix build — limpieza de variables no usadas

Después del Sprint 6.5 quedaron `const auth = useAuthStore()` sin uso en 5 archivos.
TypeScript (noUnusedLocals) rompe el build.

## Archivos corregidos (5)

```
src/modules/agents/views/AuditLogView.vue
src/modules/agents/views/InvitationsView.vue
src/modules/ai/views/AiPersonasView.vue
src/modules/channels/views/ChannelsView.vue
src/modules/knowledge/views/KnowledgeView.vue
```

## Qué cambió

- ❌ Removido: `import { useAuthStore } from '@/stores/auth.store'`
- ❌ Removido: `const auth = useAuthStore()`

En estos 5 archivos ya no se necesita `auth` porque todo se resolvió con
`activeOrgId.value` del composable `useActiveOrganizationId()`.

## Archivos que NO se tocaron

Estos 4 archivos sí usan `auth.user.*` (no solo `auth.organizationId`), entonces
el import y la declaración se quedan:

- `InboxView.vue` → usa `auth.user?.id` para currentAgentId
- `UsersView.vue` → usa `auth.user?.id` para ocultar botón "desactivar a mí mismo"
- `PlaygroundView.vue` → usa `auth.user?.fullName` en avatar
- `DashboardView.vue` → usa `auth.user?.fullName` en saludo

## Cómo evitar esto a futuro

Cada vez que un sprint reemplace el uso de `auth.organizationId`:
1. Al terminar, buscar si `auth` se usa en ALGO más dentro del archivo
2. Si no → remover también el `import` y la declaración
3. Correr `npm run build` en local antes de commit

## Aplicación

Copia los 5 archivos a sus rutas. Luego:

```powershell
npm run build
```

Debe pasar sin errores.

## Commit sugerido

```bash
git add -A
git commit -m "fix(build): remover auth huerfano en 5 views post-Sprint-6.5

Despues del Sprint 6.5 (reemplazo de auth.organizationId por
activeOrgId.value), 5 views quedaron con 'const auth = useAuthStore()'
sin uso. TypeScript noUnusedLocals rompia el build.

Removido import + declaracion de auth en:
- AuditLogView, InvitationsView (agents)
- AiPersonasView (ai)
- ChannelsView (channels)
- KnowledgeView (knowledge)"
```
