# 🚀 Sprint 7.5 + 8 — Entrega 1: Foundation

**Alcance:** Preparar el terreno (BD + tipos + repositorios) para las siguientes 3 entregas.

---

## 📦 Archivos incluidos (4)

| Ruta | Tipo | Descripción |
|---|---|---|
| `supabase/migrations/2026_sprint_7.5_8_foundation.sql` | 🆕 SQL | Migración de BD |
| `src/types/agent.types.ts` | 🔧 Reemplazar | Tipos de Agent, AgentLive, QuickReply |
| `src/repository/supabase/agent.repo.ts` | 🔧 Reemplazar | Repo de agentes con RPC de heartbeat |
| `src/repository/supabase/quick-reply.repo.ts` | 🆕 Nuevo | CRUD de quick replies |

**Nota:** Si `agent.types.ts` o `agent.repo.ts` ya existen con contenido, vale la pena
hacer backup antes de reemplazar (aunque yo trabajé con los tipos que compartiste).

---

## 🚀 Aplicación paso a paso

### Paso 1: Ejecutar la migración SQL

En Supabase Dashboard → SQL Editor → New query:

1. Abre el archivo `supabase/migrations/2026_sprint_7.5_8_foundation.sql`
2. Copia todo el contenido
3. Pégalo en el SQL Editor
4. Run (Ctrl+Enter)

**Resultado esperado:**

Al final de la ejecución, deberías ver 5 queries de verificación con resultados:

```
tabla              | columnas
quick_replies      | 11

column_name        | data_type
last_activity_at   | timestamp with time zone

routine_name
agent_heartbeat
agent_set_status
agents_auto_away

agentes_totales (>= cantidad actual de users con role agent/supervisor)

vista              | columnas
v_agents_live      | 16 o más
```

Si alguna verificación no aparece con datos, avísame.

### Paso 2: Copiar los archivos TypeScript

Reemplaza/crea los 3 archivos `.ts` en sus rutas correspondientes.

### Paso 3: Build local

```powershell
npm run build
```

Debe pasar sin errores. Si hay errores de tipos, probablemente un archivo que referencia `AgentStatus` desde el viejo tipo. Avísame y lo arreglo.

### Paso 4: Probar heartbeat manual

Abre consola del navegador (F12) en `/admin/dashboard` y corre:

```js
const { createClient } = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm')
// Solo para testeo rápido — este código funciona porque el cliente ya está en el contexto
const { supabase } = await import('/src/services/supabase.client.ts')

// Llamar al heartbeat con tu user ID
const { error } = await supabase.rpc('agent_heartbeat', {
  p_user_id: 'tu-user-id-aqui'
})
console.log('Heartbeat:', error || 'OK')
```

Si devuelve OK, la RPC está funcionando.

### Paso 5: Verificar en Supabase

En Supabase Dashboard → Table Editor → `agents`:

- Debe haber 1 registro por cada user con role `agent` o `supervisor`
- Todos deben tener `last_activity_at` con valor (backfill)

En Table Editor → `quick_replies`:

- Tabla vacía (es normal, la llenaremos en Entrega 4)

---

## 🗺️ Qué se crea

### Nuevas tablas
- **`quick_replies`** — snippets con shortcut tipo `/saludo`
  - Personal (owner_id = usuario) o compartida (is_shared = true)

### Columnas nuevas
- **`agents.last_activity_at`** — timestamp del último heartbeat

### Nuevas RPCs
- **`agent_heartbeat(user_id)`** — marca actividad + pasa a `online` si estaba `away/offline`
- **`agent_set_status(user_id, status, message?)`** — cambio manual de estado
- **`agents_auto_away(minutes = 5)`** — mueve a `away` a los inactivos

### Nueva vista
- **`v_agents_live`** — agente enriquecido con:
  - Datos del usuario (email, avatar)
  - Datos del equipo
  - Número de conversaciones activas
  - Flag `at_capacity` (si llegó al máximo)

### Nuevo trigger
- **`trg_ensure_agent_record`** — al crear o actualizar un user con role agent/supervisor, automáticamente crea su registro en `agents`

---

## 🛡️ Seguridad (RLS)

### quick_replies

| Acción | Regla |
|---|---|
| SELECT | `owner_id = auth.uid()` OR (`is_shared = true` AND mi org) |
| INSERT | `owner_id = auth.uid()` Y mi org |
| UPDATE | `owner_id = auth.uid()` |
| DELETE | `owner_id = auth.uid()` |

En palabras: solo puedo ver mis propias + las compartidas de mi org. Solo puedo editar/borrar las mías.

### agents (sin cambios)

RLS ya existente se respeta.

---

## ⚠️ Troubleshooting

### Error: "column last_activity_at already exists"
Normal si ya corriste parte del SQL. El `IF NOT EXISTS` lo previene, pero si falla igual, comenta esa línea.

### Error: "function uuid_generate_v4() does not exist"
Ejecuta primero: `CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`

### Error en RLS: "new row violates row-level security policy"
Verifica que el `organization_id` del INSERT coincida con el del usuario.

### "quick_replies" no aparece en el listado de tablas
Refresca Supabase Dashboard o corre:
```sql
SELECT * FROM quick_replies LIMIT 1;
```

---

## ✅ Checklist antes de pasar a Entrega 2

- [ ] SQL corrió sin errores
- [ ] Tabla `quick_replies` visible en Supabase
- [ ] Columna `agents.last_activity_at` visible
- [ ] Vista `v_agents_live` retorna datos al hacer `SELECT * FROM v_agents_live`
- [ ] Backfill creó agents para users existentes
- [ ] `npm run build` pasa sin errores
- [ ] Los 3 archivos TS están en sus rutas

---

## 📋 Siguiente: Entrega 2 — Módulo Contactos

Cuando valides esto, arrancamos con:

- Store `contacts.store.ts`
- Repository ampliado
- `ContactsView.vue` completa (tabla + filtros + búsqueda)
- `ContactDetailView.vue` (detalle + historial)
- Modal crear/editar contacto
- Ruta `/admin/contacts/:id`

Te aviso cuando estés listo.

---

## 💾 Commit sugerido

```bash
git add -A
git commit -m "feat(sprint-7.5+8): foundation SQL y tipos para contactos y agentes

- Nueva tabla quick_replies (personal + compartida) con RLS
- Columna agents.last_activity_at para heartbeat
- RPCs: agent_heartbeat, agent_set_status, agents_auto_away
- Vista v_agents_live con conversaciones activas y capacidad
- Trigger para auto-crear agent record al crear user con role agent/supervisor
- Backfill de registros agents existentes
- Tipos TS: Agent, AgentLive, QuickReply, AGENT_STATUS_LABELS
- Repos: SupabaseAgentRepo ampliado, SupabaseQuickReplyRepo nuevo"
```
