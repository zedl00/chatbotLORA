# 🔌 Sprint 11.5 — Channels Dashboard

Vista completa y profesional del módulo de Canales con:
- CRUD completo (crear, renombrar, duplicar, activar/desactivar, eliminar)
- Métricas por canal (conversaciones, CSAT 30d, última actividad)
- Wizard de creación en 3 pasos
- Tipos de canal con "próximamente" para WhatsApp, Telegram, etc.
- Help panel didáctico con 6 secciones
- Botón "⚙️ Configurar" que lleva a la config del widget
- Empty state premium
- Filtros por estado y tipo
- Stats resumen arriba

---

## 📦 Archivos (9)

| Ruta | Tipo | Descripción |
|---|---|---|
| `supabase/migrations/2026_sprint_11_5.sql` | 🆕 SQL | Vista v_channel_metrics + permiso delete |
| `src/types/channel.types.ts` | 🔄 | Tipos + CHANNEL_TYPES con metadata visual |
| `src/repository/supabase/channels.repo.ts` | 🆕 | CRUD + duplicate + métricas |
| `src/modules/channels/views/ChannelsView.vue` | 🔄 REEMPLAZO | Vista robusta completa |
| `src/modules/channels/components/ChannelCard.vue` | 🆕 | Card con métricas + actions |
| `src/modules/channels/components/ChannelActionsMenu.vue` | 🆕 | Dropdown ⋯ |
| `src/modules/channels/components/CreateChannelModal.vue` | 🆕 | Wizard 3 pasos |
| `src/modules/channels/components/EmptyChannelsState.vue` | 🆕 | Estado vacío |
| `src/modules/channels/components/help/ChannelsHelpPanel.vue` | 🆕 | Panel 💡 |

---

## 🚀 Aplicación

### 1. SQL
Supabase → SQL Editor → pega `2026_sprint_11_5.sql` → Run.

**Verifica al final:**
```
vista_metrics:      true
permission_delete:  true
```

También ves un preview de tus canales con métricas.

### 2. Copiar archivos (9)

### 3. Build + Deploy

```powershell
npm run build
```

---

## 🧪 Tests

### Test 1 — Vista carga con tus canales

Ve a `/admin/channels`:
- ✅ Ves 3 canales (tus existentes)
- ✅ El "Widget Web (playground)" muestra **67 conversaciones** y fecha de última actividad
- ✅ Los otros 2 muestran 0 conversaciones
- ✅ Arriba hay 4 stats: Canales totales, Activos, Inactivos, Conversaciones

### Test 2 — Filtros funcionan

- Click en "Inactivos" — si no hay, no aparece el filtro
- Click en "Activos (3)" — ves los 3

### Test 3 — Botón Configurar funciona

- Click en **⚙️ Configurar** del "Widget Web (playground)"
- ✅ Navega a `/admin/channels/widget/033fd98f...`
- ✅ Carga la vista de WidgetConfigView con tabs

### Test 4 — Copiar snippet

- Click en **📋 Copiar código**
- ✅ Toast "Código copiado al portapapeles"
- Pega en un editor de texto: debe tener el channelId correcto

### Test 5 — Eliminar canales duplicados ⭐

**Este es el fix más útil para ti.**

- Click en **⋯** del "Widget Web" (el duplicado sin conversaciones)
- ✅ Menú aparece con opciones
- Click en **🗑️ Eliminar** (debería estar habilitado porque tiene 0 convs)
- Confirma
- ✅ Toast verde "Canal eliminado"
- ✅ Lista se actualiza

Repite con el otro duplicado. Te quedarás solo con el "Widget Web (playground)" real.

### Test 6 — Crear canal nuevo

- Click en **+ Crear canal**
- ✅ Modal abre con wizard
- **Paso 1:** ves los 6 tipos, pero solo "Widget Web" está habilitado
- Los otros (WhatsApp, Telegram...) tienen badge "Sprint XX" y están deshabilitados
- Click en "Widget Web"
- **Paso 2:** formulario de nombre
- Escribe "Widget de prueba"
- Click "Crear canal"
- **Paso 3:** pantalla de éxito con próximos pasos
- Click "Configurar ahora →"
- ✅ Navega a la config del nuevo widget

### Test 7 — Renombrar

- En un canal, click **⋯ → ✏️ Renombrar**
- Prompt aparece — escribe nuevo nombre
- ✅ Canal renombrado, lista actualizada

### Test 8 — Duplicar

- Click **⋯ → 📑 Duplicar**
- ✅ Aparece canal nuevo con "(copia)" en el nombre
- Tiene toda la config del original

### Test 9 — Desactivar

- Click **⋯ → ⏸️ Desactivar**
- ✅ Indicador de estado pasa a gris "Inactivo"
- ✅ Card se ve opaca
- El botón dentro del menú cambia a "▶️ Activar"

### Test 10 — Help panel

- Click **💡 Guía** arriba
- ✅ Panel slide-in
- Expande "¿Qué es un canal?"
- Expande "¿Qué tipo de canal empezar?"
- Cierra con ✕

### Test 11 — No puedo eliminar canal con conversaciones

- Click **⋯** del "Widget Web (playground)" (67 convs)
- Botón "🗑️ Eliminar" debería estar **deshabilitado/gris**
- Hover muestra tooltip: "No se puede eliminar: tiene 67 conversaciones"

---

## 🎨 Mejoras vs la versión anterior

| Antes | Ahora |
|---|---|
| Lista simple sin métricas | Cards con CSAT, conversaciones, actividad |
| Sin botón crear | Wizard 3 pasos con tipos visuales |
| Sin eliminar | Eliminar + validación (no borra canales con convs) |
| No abre WidgetConfig | Botón "⚙️ Configurar" directo |
| Solo toggle IA | Menú completo: renombrar, duplicar, activar, eliminar |
| Sin filtros | Filtros por estado + tipo |
| Sin help | Panel con 6 secciones didácticas |
| Sin empty state | Estado vacío con CTA + canales próximos |

---

## 🧹 Después de aplicar: limpia duplicados

Tus 2 canales duplicados sin conversaciones pueden eliminarse:

1. `/admin/channels`
2. Click ⋯ en los "Widget Web" sin actividad
3. Eliminar

O desde SQL:
```sql
DELETE FROM channels 
WHERE id IN (
  '5b7bd769-c98a-4ce3-b13d-6165bc99332f',
  'ab96c07a-8555-4b6e-9ee4-85c05f7d9215'
);
```

⚠️ Confirma primero que estos IDs no tienen conversaciones.

---

## 💾 Commit

```bash
git add -A
git commit -m "feat(sprint-11.5): Channels Dashboard robusto

SQL:
- Vista v_channel_metrics (métricas por canal 30d)
- Permiso channels.delete

Frontend:
- ChannelsView completamente rediseñado
- CRUD: crear, renombrar, duplicar, activar/desactivar, eliminar
- Wizard de creación en 3 pasos con tipos visuales
- 6 tipos de canal con metadata y 'próximamente' para no disponibles
- Card con métricas: conversaciones, CSAT 30d, actividad
- Filtros por estado y tipo
- Stats resumen (total, activos, inactivos, conversaciones)
- Empty state premium con CTA
- Help panel con 6 secciones didácticas
- Botón Configurar directo a WidgetConfigView
- Validación: no eliminar canales con conversaciones"

git push
```

---

## 🎯 Después de esto

Roadmap pendiente:
- Sprint 12: Help System framework + docs retroactivas
- Sprint 13: Landing lorachat.net
- Sprint 14: Telegram
- Sprint 15: Stripe
- Sprint 16: WhatsApp
- Sprint 17: Constructor de flujos
