// Ruta: /src/types/channel.types.ts
// ═══════════════════════════════════════════════════════════════
// Sprint 11.5 · Tipos de canales con metadata visual
// ═══════════════════════════════════════════════════════════════

export type ChannelType = 'web_widget' | 'whatsapp' | 'telegram' | 'instagram' | 'messenger' | 'email'

export interface Channel {
  id: string
  organizationId: string
  type: ChannelType
  name: string
  active: boolean
  settings: Record<string, any>
  defaultPersonaId: string | null
  externalId: string | null
  createdAt: string
  updatedAt: string
}

export interface ChannelMetrics {
  channelId: string
  name: string
  type: ChannelType
  active: boolean
  totalConversations: number
  conversations30d: number
  lastActivityAt: string | null
  avgCsat30d: number | null
  csatCount30d: number
  createdAt: string
}

export interface CreateChannelInput {
  type: ChannelType
  name: string
  defaultPersonaId?: string | null
}

// ─── Metadata visual por tipo ───

export interface ChannelTypeMetadata {
  type: ChannelType
  label: string
  icon: string
  description: string
  available: boolean
  availableAt?: string  // Sprint en que estará disponible
  tagline: string       // frase corta para el type picker
  setupDifficulty: 'easy' | 'medium' | 'hard'
  color: string         // para los iconos grandes
}

export const CHANNEL_TYPES: ChannelTypeMetadata[] = [
  {
    type: 'web_widget',
    label: 'Widget Web',
    icon: '🌐',
    description: 'Widget embebible en tu sitio web. Tus visitantes chatean directo desde cualquier página.',
    available: true,
    tagline: 'Chat en tu sitio web',
    setupDifficulty: 'easy',
    color: '#0071E3'
  },
  {
    type: 'whatsapp',
    label: 'WhatsApp Business',
    icon: '📱',
    description: 'Recibe y responde mensajes de WhatsApp. Requiere API oficial de Meta (2-4 semanas de aprobación).',
    available: false,
    availableAt: 'Sprint 15',
    tagline: 'El canal #1 en LATAM',
    setupDifficulty: 'hard',
    color: '#25D366'
  },
  {
    type: 'telegram',
    label: 'Telegram',
    icon: '✈️',
    description: 'Bot de Telegram con API gratuita. Setup rápido sin aprobaciones.',
    available: false,
    availableAt: 'Sprint 14',
    tagline: 'Setup en 5 minutos',
    setupDifficulty: 'easy',
    color: '#0088CC'
  },
  {
    type: 'instagram',
    label: 'Instagram Direct',
    icon: '📷',
    description: 'Mensajes directos de Instagram. Requiere cuenta Business + Facebook Page.',
    available: false,
    availableAt: 'Sprint 16',
    tagline: 'DMs de Instagram',
    setupDifficulty: 'medium',
    color: '#E4405F'
  },
  {
    type: 'messenger',
    label: 'Facebook Messenger',
    icon: '💬',
    description: 'Mensajes de tu página de Facebook. Requiere Facebook Page con admin access.',
    available: false,
    availableAt: 'Sprint 16',
    tagline: 'Messenger de Facebook',
    setupDifficulty: 'medium',
    color: '#006AFF'
  },
  {
    type: 'email',
    label: 'Email',
    icon: '✉️',
    description: 'Convierte emails entrantes en conversaciones. Soporta Gmail, Outlook y SMTP.',
    available: false,
    availableAt: 'Sprint 18',
    tagline: 'Emails como conversaciones',
    setupDifficulty: 'medium',
    color: '#EA4335'
  }
]

export function getChannelMetadata(type: ChannelType): ChannelTypeMetadata {
  return CHANNEL_TYPES.find(c => c.type === type) ?? CHANNEL_TYPES[0]
}

// Helper: formatear "hace X tiempo"
export function timeSince(iso: string | null): string {
  if (!iso) return 'Nunca'
  const d = new Date(iso).getTime()
  const now = Date.now()
  const diff = now - d
  const min = Math.floor(diff / 60000)
  if (min < 1) return 'Hace unos segundos'
  if (min < 60) return `Hace ${min} min`
  const h = Math.floor(min / 60)
  if (h < 24) return `Hace ${h}h`
  const days = Math.floor(h / 24)
  if (days < 7) return `Hace ${days}d`
  if (days < 30) return `Hace ${Math.floor(days / 7)}sem`
  if (days < 365) return `Hace ${Math.floor(days / 30)}m`
  return `Hace ${Math.floor(days / 365)}a`
}
