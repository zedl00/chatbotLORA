# 🔧 Fix: inbox.types.ts con 'whisper' agregado

## Cambio mínimo

**1 línea** en `src/types/inbox.types.ts`:

### Antes:
```ts
export type MessageSenderType = 'contact' | 'bot' | 'agent' | 'system'
```

### Ahora:
```ts
export type MessageSenderType = 'contact' | 'bot' | 'agent' | 'system' | 'whisper'
```

Nota: tu archivo **ya tenía** `'system'`. Solo faltaba `'whisper'`.

## Pasos

1. Copia `src/types/inbox.types.ts` a tu proyecto
2. `npm run build` → debe pasar ✅
3. Si pasa, `npm run dev` para smoke tests
4. Deploy FTP

## Si aparece otro error nuevo
Pégamelo y lo resolvemos.
