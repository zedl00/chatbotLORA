# Sprint 7.5 — Rebranding público del widget LORA

Rebranding completo del widget embebible + archivos relacionados. Aplica cambios visibles a **clientes finales** (visitantes que chatean desde sitios como jabenter.com).

---

## 📦 Archivos incluidos (6)

```
lora-widget-premium/
├── README.md                                     ← este archivo
├── CHANGELOG.md                                  ← lista detallada de cambios
│
├── public/
│   └── widget.js                                 ← ★ widget PREMIUM v2.0
│
├── widget/
│   ├── public/
│   │   └── demo.html                             ← página de demo rebrandeada
│   └── src/
│       └── widget.js                             ← espejo del anterior (fuente)
│
└── src/
    ├── services/
    │   └── supabase.client.ts                    ← con migración suave
    └── modules/channels/components/
        ├── WidgetInstallSnippet.vue              ← snippet apunta a admin.lorachat.net
        └── WidgetConfigEditor.vue                ← label "Powered by LORA"
```

---

## 🎯 Lo que cambió (resumen ejecutivo)

### Visual / Branding (el cliente final lo ve)
- ✨ **Paleta LORA** aplicada (azul `#0071E3` + gradients)
- 🎬 **Launcher con bounce-in animation** al cargar
- 💫 **Panel con fade + scale** al abrir
- 💬 **Mensajes con entrada progresiva** (fade + slide)
- ⚡ **Typing indicator** con 3 puntos azules animados
- 🎨 **Header con gradient + shine** sutil
- 🟢 **Status "En línea · Responde rápido"** con dot verde pulsante
- 📱 **Mobile: fullscreen automático** en < 480px
- 🏷️ **Unread counter** (1, 2... 9+) en la burbuja cuando hay mensajes nuevos
- 🔵 **Botón enviar con gradient y shadow colored**
- 🎯 **Focus rings accesibles** en todos los elementos interactivos

### Marca
- 📛 "ChatBot IA" → **"LORA"** en todo el widget público
- 🔗 "Powered by" → **"LORA"** (minimal, clickeable, lleva a lorachat.net)
- 🗂️ Namespaces internos: `cbi-*` → `lora-*`, `__ChatBotIAWidget` → `__LoraWidget` (con alias)

### Técnico
- 🔄 **Migración suave** del `storageKey` → nadie se desloga
- 🔄 **Migración suave** del `localStorage` del visitorId
- 🌐 **Snippet apunta a `https://admin.lorachat.net/widget.js`** en producción
- ♿ **Accesibilidad mejorada**: ARIA labels, escape key, roles, focus visible
- 📏 **Textarea auto-resize** hasta 100px
- 🖼️ **Icon SVG para "enviar"** en vez de flecha de texto
- 🧹 **HTML escape reforzado** (+ comillas)
- 🔇 **Respeta `prefers-reduced-motion`** (desactiva animaciones si el usuario lo configuró)

---

## 🚀 Estrategia de deploy (IMPORTANTE)

El widget está **vivo en jabenter.com** con la v1. No puedes subir el v2 de golpe porque si algo rompe, rompe para visitantes reales. Haz esto:

### FASE 1 — Aplicar cambios al admin (sin impacto visible)

Los 3 archivos bajo `src/` no afectan al widget público todavía. Pueden subirse con confianza:

```powershell
cd C:\xampp\htdocs\proyectos\chatbot

# Branch de seguridad
git checkout -b feat/sprint-7.5-rebranding-publico

# Copia los 3 archivos:
# - src/services/supabase.client.ts
# - src/modules/channels/components/WidgetInstallSnippet.vue
# - src/modules/channels/components/WidgetConfigEditor.vue

# Verifica que compila
npm run typecheck
npm run build

# Sube /dist vía FTP a admin.lorachat.net
```

**Validación FASE 1:**
1. Abre https://admin.lorachat.net en incógnito
2. Haz login → deberías entrar sin problemas (la migración del storageKey es transparente)
3. Ve a Canales → selecciona uno → verifica:
   - El snippet en el bloque de código apunta a `https://admin.lorachat.net/widget.js` ✓
   - El comentario dice `<!-- LORA Chat Widget -->` ✓
   - El checkbox dice `Mostrar "Powered by LORA"` ✓

### FASE 2 — Deploy del widget v2 en paralelo (sin romper el v1)

Subes el widget nuevo con nombre distinto para que el v1 siga vivo:

1. Toma el archivo `public/widget.js` del ZIP
2. **Renómbralo temporalmente a `widget-v2.js`**
3. Súbelo vía FTP a `/public_html/` de **admin.lorachat.net** (junto al `widget.js` actual)

Resultado: ahora tienes 2 widgets disponibles:
- `https://admin.lorachat.net/widget.js` ← v1 (el que usa jabenter.com hoy)
- `https://admin.lorachat.net/widget-v2.js` ← v2 nuevo (nadie lo usa todavía)

### FASE 3 — Validación del v2 antes de activarlo

Crea un CodePen de prueba para validar el v2 aislado:

```html
<!DOCTYPE html>
<html>
<head><title>Test LORA v2</title></head>
<body>
  <h1>Test widget v2</h1>

  <script
    src="https://admin.lorachat.net/widget-v2.js"
    data-channel-id="033fd98f-be93-4bf5-b090-94e26f091d94"
    data-supabase-url="https://imvahmyywbtcfsduwbdq.supabase.co"
    data-supabase-anon-key="TU_ANON_KEY"
    async
  ></script>
</body>
</html>
```

**Checklist de validación:**
- [ ] El launcher aparece con animación bounce-in
- [ ] Al hacer click, el panel se abre con animación fade+scale
- [ ] El header tiene gradient azul + dot verde pulsante
- [ ] Puedes escribir un mensaje y el bot responde
- [ ] Aparece el typing indicator mientras el bot piensa
- [ ] Los mensajes aparecen con animación suave
- [ ] Al cerrar y abrir otra pestaña, la sesión persiste
- [ ] "LORA" aparece en el footer (si está activado)
- [ ] Click en "LORA" abre https://lorachat.net en nueva pestaña
- [ ] Prueba en móvil (DevTools → responsive mode < 480px) → fullscreen
- [ ] Presionar Escape cierra el panel
- [ ] Tab navigation funciona (focus rings azules)

### FASE 4 — Promoción a producción

Cuando confirmes que el v2 funciona 100%:

1. **Backup del v1**: descarga una copia de `admin.lorachat.net/widget.js` a tu máquina
2. **Renombra en el servidor**: `widget.js` → `widget-v1-backup.js`
3. **Renombra el nuevo**: `widget-v2.js` → `widget.js`

Ahora todos los sitios que usan `https://admin.lorachat.net/widget.js` reciben el v2 automáticamente.

### FASE 5 — Romper caché en los sitios instalados

Los navegadores pueden tener cacheado el v1. Para forzar el refresh, actualiza el snippet en **jabenter.com**:

```html
<!-- Antes -->
<script src="https://admin.lorachat.net/widget.js" ...></script>

<!-- Después (fuerza re-descarga) -->
<script src="https://admin.lorachat.net/widget.js?v=2" ...></script>
```

Rebuildea jabenter.com y sube el nuevo `index.html`.

### FASE 6 — Validación final end-to-end

1. Abre https://jabenter.com en incógnito
2. Deberías ver el widget **v2** (launcher con bounce, panel con fade+scale)
3. Envía un mensaje
4. Abre https://admin.lorachat.net → Inbox → el mensaje aparece en tiempo real
5. Responde desde el inbox → llega al widget en jabenter.com al instante

### 🆘 Rollback en 30 segundos (si algo falla)

Si algo se rompe en producción después del FASE 4:

```
1. Entra por FTP a admin.lorachat.net
2. Renombra widget.js → widget-broken.js
3. Renombra widget-v1-backup.js → widget.js
4. (Opcional) Quita ?v=2 del snippet en jabenter.com

El v1 vuelve a estar activo. Los usuarios ni se enteraron.
```

---

## ✅ Validación técnica automática

Después de aplicar los 3 archivos del admin (FASE 1), corre esto para confirmar que no quedaron referencias viejas visibles en la UI del admin:

```powershell
cd C:\xampp\htdocs\proyectos\chatbot

# Solo mira el frontend del admin, no docs ni widget (que rebrandeamos separado)
Get-ChildItem -Recurse -File -Include *.ts,*.vue |
  Where-Object { $_.FullName -notmatch "node_modules|dist|\.git|widget\\|docs\\" } |
  Select-String -Pattern "ChatBot IA|chatbot-ia" |
  Select-Object Path, LineNumber, Line |
  Format-Table -Wrap
```

Debería salir **vacío**. Si queda algo, dímelo y lo resolvemos.

---

## 🎨 Paleta usada

```
Primary:      #0071E3  (Apple blue)
Primary dark: ~#005BB5 (auto-calculado por el widget con adjustColor)
Cyan:         #06B6D4  (acento)
Violet:       #8B5CF6  (en el brand mark del demo)
Ink:          #0A0A0A
Slate:        #475569
Success:      #4ade80  (dot de "en línea")
Error:        #ef4444  (badge de no leídos)
```

El widget **respeta el `primary_color` que el cliente configura en el admin** y deriva automáticamente el dark con `adjustColor()`. Si el cliente usa rojo, todo el gradient se recalcula.

---

## 📝 Pendientes después del deploy

Cuando el widget v2 esté estable en producción (~60 días):

- [ ] Eliminar bloque de migración suave en `supabase.client.ts`
- [ ] Eliminar migración del `OLD_VISITOR_KEY` en `widget.js`
- [ ] Eliminar alias `window.__ChatBotIAWidget` en `widget.js`
- [ ] Borrar `widget-v1-backup.js` del servidor
- [ ] Actualizar `estado-proyecto.md` con la versión 2.0 oficial

---

## 🎯 Qué no está incluido en este sprint

Lo siguiente quedó intencionalmente fuera para no inflar este rebranding:

- **Dark mode del widget** (para sitios con tema oscuro): requiere lógica de detección + paleta completa de dark mode. Va en otro sprint.
- **Quick replies / botones sugeridos**: requiere cambios en el backend de `widget-message`. Sprint futuro.
- **Historial de conversaciones para usuarios recurrentes**: ya está pero podría mejorarse la UX.
- **Upload de archivos**: requiere storage + validaciones. Sprint dedicado.
- **Notificación de sonido**: requiere permisos + asset de audio. Sprint futuro.

---

**© 2026 Jab Enterprises · LORA Chat Widget v2.0.0**
