-- ═══════════════════════════════════════════════════════════════
-- Sprint 9 · Fix: sender_agent_id → sender_id
--
-- La columna correcta en public.messages es sender_id (uuid),
-- no sender_agent_id como había puesto.
--
-- Nota: sender_id probablemente apunta a users.id (no agents.id).
-- Para whisper, el autor es el user que escribe.
-- Para system messages, sender_id puede ser NULL (no hay autor humano).
-- ═══════════════════════════════════════════════════════════════

BEGIN;

-- ─────────────────────────────────────────────────────────────
-- 1. RPC send_whisper (corregido)
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION send_whisper(
  p_conversation_id UUID,
  p_content TEXT
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id UUID;
  v_org_id UUID;
  v_msg_id UUID;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'No autenticado';
  END IF;

  IF p_content IS NULL OR trim(p_content) = '' THEN
    RAISE EXCEPTION 'El contenido no puede estar vacío';
  END IF;

  SELECT organization_id INTO v_org_id
  FROM conversations WHERE id = p_conversation_id;

  IF v_org_id IS NULL THEN
    RAISE EXCEPTION 'Conversación no encontrada';
  END IF;

  -- 🔧 sender_id en vez de sender_agent_id
  INSERT INTO messages (
    conversation_id, organization_id, sender_type, sender_id,
    content, content_type, status, metadata
  ) VALUES (
    p_conversation_id, v_org_id,
    'whisper'::sender_type,
    v_user_id,
    p_content, 'text', 'delivered',
    jsonb_build_object('is_whisper', true)
  )
  RETURNING id INTO v_msg_id;

  RETURN v_msg_id;
END;
$$;

GRANT EXECUTE ON FUNCTION send_whisper(UUID, TEXT) TO authenticated;


-- ─────────────────────────────────────────────────────────────
-- 2. RPC supervisor_takeover (corregido)
-- El mensaje system no usa sender_id (queda NULL - sin autor humano)
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION supervisor_takeover(p_conversation_id UUID)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_supervisor_user_id UUID;
  v_supervisor_agent_id UUID;
  v_old_agent_id UUID;
  v_old_agent_user_id UUID;
  v_org_id UUID;
  v_escalation_id UUID;
BEGIN
  v_supervisor_user_id := auth.uid();
  IF v_supervisor_user_id IS NULL THEN
    RAISE EXCEPTION 'No hay usuario autenticado';
  END IF;

  SELECT c.organization_id, c.agent_id, a.user_id
  INTO v_org_id, v_old_agent_id, v_old_agent_user_id
  FROM conversations c
  LEFT JOIN agents a ON a.id = c.agent_id
  WHERE c.id = p_conversation_id;

  IF v_org_id IS NULL THEN
    RAISE EXCEPTION 'Conversación no encontrada';
  END IF;

  SELECT id INTO v_supervisor_agent_id
  FROM agents WHERE user_id = v_supervisor_user_id;

  IF v_supervisor_agent_id IS NULL THEN
    RAISE EXCEPTION 'El supervisor no tiene registro en agents';
  END IF;

  UPDATE conversations
  SET agent_id = v_supervisor_agent_id,
      assigned_at = NOW(),
      updated_at = NOW()
  WHERE id = p_conversation_id;

  INSERT INTO escalations (
    organization_id, conversation_id, type, actor_id, from_user_id, to_user_id, metadata
  ) VALUES (
    v_org_id, p_conversation_id, 'takeover',
    v_supervisor_user_id, v_old_agent_user_id, v_supervisor_user_id,
    jsonb_build_object('reason', 'supervisor_takeover')
  )
  RETURNING id INTO v_escalation_id;

  UPDATE escalations
  SET resolved = true, resolved_at = NOW(), resolved_by = v_supervisor_user_id
  WHERE conversation_id = p_conversation_id
    AND type = 'sla_breach'
    AND resolved = false;

  -- 🔧 system message sin sender_id (es automático, no tiene autor humano)
  INSERT INTO messages (
    conversation_id, organization_id, sender_type, content, content_type, status
  ) VALUES (
    p_conversation_id, v_org_id,
    'system'::sender_type,
    'Un supervisor tomó el control de esta conversación.',
    'text', 'delivered'
  );

  RETURN v_escalation_id;
END;
$$;

GRANT EXECUTE ON FUNCTION supervisor_takeover(UUID) TO authenticated;


-- ─────────────────────────────────────────────────────────────
-- 3. RPC reassign_conversation (corregido)
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION reassign_conversation(
  p_conversation_id UUID,
  p_new_agent_id UUID
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_actor_user_id UUID;
  v_old_agent_id UUID;
  v_old_agent_user_id UUID;
  v_new_agent_user_id UUID;
  v_new_agent_name TEXT;
  v_org_id UUID;
  v_escalation_id UUID;
BEGIN
  v_actor_user_id := auth.uid();
  IF v_actor_user_id IS NULL THEN
    RAISE EXCEPTION 'No autenticado';
  END IF;

  SELECT c.organization_id, c.agent_id, a.user_id
  INTO v_org_id, v_old_agent_id, v_old_agent_user_id
  FROM conversations c
  LEFT JOIN agents a ON a.id = c.agent_id
  WHERE c.id = p_conversation_id;

  IF v_org_id IS NULL THEN
    RAISE EXCEPTION 'Conversación no encontrada';
  END IF;

  SELECT a.user_id, u.full_name
  INTO v_new_agent_user_id, v_new_agent_name
  FROM agents a
  JOIN users u ON u.id = a.user_id
  WHERE a.id = p_new_agent_id AND a.organization_id = v_org_id;

  IF v_new_agent_user_id IS NULL THEN
    RAISE EXCEPTION 'Agente destino no encontrado o pertenece a otra org';
  END IF;

  UPDATE conversations
  SET agent_id = p_new_agent_id,
      assigned_at = NOW(),
      updated_at = NOW()
  WHERE id = p_conversation_id;

  INSERT INTO escalations (
    organization_id, conversation_id, type, actor_id, from_user_id, to_user_id, metadata
  ) VALUES (
    v_org_id, p_conversation_id, 'reassign',
    v_actor_user_id, v_old_agent_user_id, v_new_agent_user_id,
    jsonb_build_object('reason', 'manual_reassign')
  )
  RETURNING id INTO v_escalation_id;

  UPDATE escalations
  SET resolved = true, resolved_at = NOW(), resolved_by = v_actor_user_id
  WHERE conversation_id = p_conversation_id
    AND type = 'sla_breach'
    AND resolved = false;

  -- 🔧 system message sin sender_id
  INSERT INTO messages (
    conversation_id, organization_id, sender_type, content, content_type, status
  ) VALUES (
    p_conversation_id, v_org_id,
    'system'::sender_type,
    format('Conversación reasignada a %s.', COALESCE(v_new_agent_name, 'agente')),
    'text', 'delivered'
  );

  RETURN v_escalation_id;
END;
$$;

GRANT EXECUTE ON FUNCTION reassign_conversation(UUID, UUID) TO authenticated;


COMMIT;


-- ═══════════════════════════════════════════════════════════════
-- Verificación rápida
-- ═══════════════════════════════════════════════════════════════
SELECT 'RPCs_updated' AS check_,
       COUNT(*) AS count_,
       string_agg(routine_name, ', ' ORDER BY routine_name) AS names_
FROM information_schema.routines
WHERE routine_name IN ('send_whisper', 'supervisor_takeover', 'reassign_conversation');
