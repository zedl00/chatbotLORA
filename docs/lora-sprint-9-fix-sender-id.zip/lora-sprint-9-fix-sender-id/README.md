# 🔧 Fix: sender_agent_id → sender_id

## 🐛 Error que viste

```
column "sender_agent_id" of relation "messages" does not exist
```

Al intentar enviar whisper.

## 🔍 Causa

En tu tabla `messages` la columna se llama **`sender_id`** (no `sender_agent_id`).
Mis 3 RPCs (send_whisper, supervisor_takeover, reassign_conversation) usaban
el nombre incorrecto.

## ✅ Fix

Corrige los 3 RPCs para usar `sender_id`:

- **`send_whisper`:** ahora `sender_id = auth.uid()` (el usuario que escribe)
- **`supervisor_takeover`:** el mensaje system queda sin sender_id (es automático)
- **`reassign_conversation`:** igual, mensaje system sin sender_id

## 🚀 Aplicación

1. Abre Supabase → SQL Editor → **New Query**
2. Pega el contenido de `fix_sender_id.sql`
3. Run

**Verificación esperada al final:**
```
RPCs_updated : 3
names_       : reassign_conversation, send_whisper, supervisor_takeover
```

## 🧪 Prueba inmediata

1. Ve al Inbox
2. Abre una conversación tuya
3. Activa toggle `🤫 Whisper`
4. Escribe: "Prueba sender_id fix"
5. Click 🤫

**✅ Esperado ahora:**
- Toast "Whisper enviado al equipo"
- Bubble amarillo con borde punteado aparece

## 📝 Nota sobre frontend

**No hay que tocar el frontend.** El INSERT lo hace el RPC en el backend.
El frontend solo llama a `supabase.rpc('send_whisper', ...)` y el resultado
llega al `ConversationThread` vía realtime como cualquier mensaje normal.

## 🧠 Por qué pasó

No verifiqué la estructura exacta de `messages` antes de escribir los RPCs.
Asumí `sender_agent_id` por analogía con `conversations.agent_id`, pero la
convención en tu tabla es diferente (`sender_id` apunta directamente a users).

Lección para próximos sprints: antes de escribir INSERTs/UPDATEs, siempre
verificar con:
```sql
SELECT column_name FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'messages';
```

El filtro `table_schema = 'public'` es clave — Supabase tiene otras tablas
con el mismo nombre en schemas internos (realtime, etc.).
