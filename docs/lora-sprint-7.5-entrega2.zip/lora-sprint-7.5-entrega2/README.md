# 📇 Sprint 7.5 — Entrega 2: Módulo de Contactos

Implementación completa del módulo de Contactos del admin.

---

## 📦 Archivos incluidos (7)

| Ruta | Tipo | Descripción |
|---|---|---|
| `src/modules/contacts/views/ContactsView.vue` | 🔧 Reemplazar | Lista con filtros + búsqueda + stats |
| `src/modules/contacts/views/ContactDetailView.vue` | 🆕 Nuevo | Detalle + historial conversaciones |
| `src/modules/contacts/components/ContactFormModal.vue` | 🆕 Nuevo | Modal crear/editar |
| `src/modules/contacts/components/TagInput.vue` | 🆕 Nuevo | Input de tags con autocomplete |
| `src/repository/supabase/contact.repo.ts` | 🔧 Reemplazar | Ampliado con listContacts, stats, listConversationsByContact, listAllTags |
| `src/router/index.ts` | 🔧 Reemplazar | Nueva ruta `/admin/contacts/:id` |
| `src/modules/inbox/components/ContactPanel.vue` | 🔧 Reemplazar | Botón "Ver perfil completo →" |

---

## 🚀 Aplicación

### Paso 1: Copiar los archivos

Copia los 7 archivos a sus rutas correspondientes (todos vienen con ruta completa desde `/src`).

### Paso 2: Build local

```powershell
npm run build
```

**Debe pasar sin errores.** Si hay alguno, avísame.

### Paso 3: Dev

```powershell
npm run dev
```

### Paso 4: Probar

Ve al panel y prueba en orden:

#### Test A — Vista vacía / crear manual

1. `/admin/contacts`
2. Ves stats en 0 (o los que tengas) + empty state si no hay contactos
3. Click en "+ Nuevo contacto"
4. Llena: Nombre "Test Juan", Email "juan@test.com", Phone "+1 809 555-0100"
5. Agrega un par de tags: "vip", "cliente"
6. Click "Crear contacto"
7. **Esperado:** Toast verde, modal cierra, aparece en la lista

#### Test B — Filtros

1. Con al menos 2-3 contactos creados o reales del widget
2. Escribe en búsqueda: "juan" → filtra por nombre
3. Borra y escribe email parcial
4. Cambia selector "Todos los canales" a uno específico
5. Cambia selector "Todas las tags" a una tag existente
6. **Esperado:** La tabla se actualiza con debounce (400ms) en la búsqueda

#### Test C — Detalle del contacto

1. Click en una fila de la tabla
2. **Esperado:** Navegas a `/admin/contacts/:id`
3. Ves info del contacto, tags editables, historial
4. Click en "Editar" → abre modal con data precargada
5. Cambia algo y guarda
6. **Esperado:** Data actualizada, modal cierra

#### Test D — Tags inline

1. En el detalle, agrega una tag nueva escribiendo y Enter
2. **Esperado:** Se guarda automáticamente, toast verde
3. Click en × sobre una tag existente
4. **Esperado:** Se elimina y guarda

#### Test E — Bloquear / desbloquear

1. En el detalle, click "🚫 Bloquear contacto"
2. **Esperado:** Toast warning, label cambia a "✓ Desbloquear"
3. Click de nuevo → desbloquea

#### Test F — Desde Inbox

1. Ve a `/admin/inbox`
2. Abre cualquier conversación
3. En el panel derecho (ContactPanel), debajo del nombre ves:
   **"Ver perfil completo →"**
4. Click
5. **Esperado:** Navegas al detalle del contacto

#### Test G — Multi-tenant

1. `.env.local` → `VITE_DEV_SUBDOMAIN=capitali`
2. Reinicia dev
3. Login super_admin
4. Ve a Contactos
5. **Esperado:** Solo contactos de Capitali (probablemente 0)

---

## 🎨 Qué puede hacer el usuario

### En `/admin/contacts`:
- ✅ Ver lista de contactos con stats (total, nuevos semana)
- ✅ Buscar por nombre, email o teléfono (con debounce)
- ✅ Filtrar por canal (web widget, whatsapp, etc.)
- ✅ Filtrar por tag
- ✅ Crear contacto manual (nombre + email/teléfono obligatorio)
- ✅ Ver máx 50 por página

### En `/admin/contacts/:id`:
- ✅ Ver info completa del contacto
- ✅ Editar tags inline con autocompletado
- ✅ Editar datos abriendo modal
- ✅ Ver historial de conversaciones con estado + CSAT + agente
- ✅ Ver mini stats (abiertas, resueltas, CSAT promedio)
- ✅ Ver canales en los que está
- ✅ Leer notas internas
- ✅ Bloquear/desbloquear
- ✅ Click en conversación → va al Inbox

### En `/admin/inbox`:
- ✅ Desde el ContactPanel, botón "Ver perfil completo →" lleva al detalle

---

## ⚠️ Limitaciones conocidas

### 1. Widget no captura datos de contacto todavía
Los contactos que entran por el widget vienen con `fullName = null`, `email = null`. 
Esto se resuelve en **Entrega 2.5 — Pre-chat widget configurable** (siguiente).

### 2. Click en conversación del historial
Actualmente va al Inbox general (no abre la conversación específica). 
Se puede mejorar pasando `?conversationId=X` en futuras entregas.

### 3. Paginación
Por ahora carga los primeros 50. No hay "ver más" ni scroll infinito. 
Ampliable en sprint futuro si se necesita.

### 4. Export CSV
No incluido. Ampliable en Sprint 11 (Agent Analytics) si se requiere.

---

## 🔧 Qué cambió en el repo

### `contact.repo.ts` — nuevos métodos

```ts
listContacts(orgId, filters)              // con search + channel + tag filter
getStats(orgId)                            // total, newThisWeek, blocked
listAllTags(orgId)                         // para autocompletado
listConversationsByContact(contactId, limit) // historial
```

---

## 💾 Commit sugerido

```bash
git add -A
git commit -m "feat(sprint-7.5): modulo de contactos completo

- ContactsView: tabla con filtros, busqueda, stats, paginacion 50
- ContactDetailView: detalle con historial de conversaciones,
  tags editables inline, bloquear/desbloquear
- ContactFormModal: crear/editar con validacion
- TagInput: autocompletado de tags existentes
- Ruta /admin/contacts/:id en el router
- Link 'Ver perfil completo' desde ContactPanel del Inbox
- contact.repo ampliado: listContacts con filtros, getStats,
  listAllTags, listConversationsByContact

Multi-tenant: todas las queries usan useActiveOrganizationId"
```

---

## 🎯 Siguiente

Cuando valides todo, pasamos a:

### Entrega 2.5 — Pre-chat widget configurable (1-1.5h)
- Ampliar `widget_configs` con settings de pre-chat
- Editor en `/admin/channels` para cada tenant
- Widget muestra formulario antes del chat
- → los contactos empiezan a llenarse automáticamente

### Entrega 3 — Agent Presence (1h)
- Heartbeat + estado en tiempo real
- Indicador en sidebar

### Entrega 4 — Agent Workspace (2h)
- Vista AgentsView
- Quick replies CRUD
- Integraciones

---

## 🐛 Troubleshooting

### "Error cargando contactos: column contacts.xxx does not exist"
Alguna columna del repo no coincide con tu DB. Pégame el error y lo arreglo.

### "Route 'admin.contact-detail' not found"
El router nuevo no se aplicó. Verifica que `router/index.ts` tenga la ruta.

### El botón "Ver perfil completo" no aparece
La conversación no tiene `contactId`. Es raro pero posible si el widget creó la conversación sin contacto. Verifica en BD.

### El TagInput no muestra sugerencias
Normal si la org no tiene contactos con tags todavía. Crea 2 contactos con tags y prueba.

### "Could not embed because more than one relationship found"
Algún FK colisionante que no arreglamos en Sprint 6.8. Pégame el error completo y lo arreglo.
