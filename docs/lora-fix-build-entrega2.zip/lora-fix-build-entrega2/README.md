# 🔧 Fix build — Entrega 2

Arregla 2 errores de TypeScript que aparecieron al hacer `npm run build`.

---

## 🐛 Errores corregidos

### 1. TagInput.vue (línea 99)
**Error:** `Property 'setTimeout' does not exist on type...`

**Causa:** Vue 3 con TypeScript estricto no permite llamar funciones globales
del navegador directamente en el template. `setTimeout` no está expuesto en
el contexto del componente por defecto.

**Fix:** Movido `setTimeout` al script como función `handleBlur()` y se llama
desde el template con `@blur="handleBlur"`.

### 2. ContactsView.vue (línea 18)
**Error:** `'truncate' is declared but its value is never read.`

**Causa:** Import sin uso. La clase CSS `truncate` de Tailwind que sí se usa
en el template no requiere ser importada.

**Fix:** Removido `truncate` del import de `@/utils/format`.

---

## 📦 Archivos

| Ruta | Cambio |
|---|---|
| `src/modules/contacts/components/TagInput.vue` | 🔧 Reemplazar |
| `src/modules/contacts/views/ContactsView.vue` | 🔧 Reemplazar |

---

## 🚀 Aplicación

1. Copia los 2 archivos a sus rutas
2. `npm run build` — debe pasar ✓

---

## 💡 Cómo evitar esto a futuro

TypeScript estricto es muy útil pero ruidoso:

### Patrón de globales en templates
```vue
<!-- ❌ MAL: funciones globales inline -->
<input @blur="setTimeout(() => showX = false, 200)" />

<!-- ✅ BIEN: handler en script -->
<input @blur="handleBlur" />
```

### Patrón de imports
Antes de commit, revisa que todos los imports se usen. VS Code muestra
imports sin uso con subrayado gris (si tienes ESLint configurado).

Alternativa: agrega en `tsconfig.json`:
```json
"noUnusedLocals": false  // ← relaja, pero PELIGROSO: esconde bugs
```

Mejor: mantener `noUnusedLocals: true` y limpiar al commitear.
