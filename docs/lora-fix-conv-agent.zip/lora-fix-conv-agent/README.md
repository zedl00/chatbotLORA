# 🔧 Fix: conversations.agent_id apunta a agents, no users

## 🐛 Problema

Error en consola al abrir detalle de contacto:
```
Could not find a relationship between 'conversations' and 'users' in the schema cache
```

## 🔍 Causa

Mi query en `listConversationsByContact` asumía:
```
conversations.agent_id → users.id
```

Pero la realidad es:
```
conversations.agent_id → agents.id
agents.user_id → users.id
```

Son DOS saltos, no uno.

## ✅ Fix

Doble embed en la query:

**Antes (roto):**
```ts
.select(`
  ...,
  agent:users!conversations_agent_id_fkey(full_name)
`)
```

**Ahora (funciona):**
```ts
.select(`
  ...,
  agent:agents!conversations_agent_id_fkey(
    user:users!agents_user_id_fkey(full_name)
  )
`)
```

Y para leer el nombre: `conv.agent?.user?.full_name`

## 📦 Archivo

- `src/repository/supabase/contact.repo.ts` — reemplazar

## 🚀 Pasos

1. Copiar el archivo
2. Recargar la app
3. Entrar a un contacto → ver historial
4. Ya NO debe aparecer el error en consola
5. Los nombres de agentes se ven correctamente en el historial

## 💡 Nota de arquitectura

**Todo el sistema respeta este patrón:** `conversations.agent_id` es un FK a
`agents.id` (la tabla con config de agente), NO directamente a `users.id`.

Cualquier query futura que muestre "nombre del agente de la conversación"
debe hacer ese doble salto, o usar `v_agents_live` que ya lo resuelve.

## ⏭️ Pendiente Fix B (bloqueo funcional)

Cuando me subas `supabase/functions/widget-message/index.ts` te doy el
segundo ZIP con el check de `contacts.blocked` para que el widget
efectivamente rechace mensajes de contactos bloqueados.
