// Ruta: /src/stores/organization.store.ts
// ═══════════════════════════════════════════════════════════════
// Store de Pinia para la organización activa (tenant actual).
// Sprint 5 · Bloque 3.
// ═══════════════════════════════════════════════════════════════
import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { supabase } from '@/services/supabase.client'
import { useOrganizationContext } from '@/composables/useOrganizationContext'
import type { OrganizationContext } from '@/types/organization.types'

export const useOrganizationStore = defineStore('organization', () => {
  // ── STATE ──────────────────────────────────────────────
  const current = ref<OrganizationContext | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)
  const loaded = ref(false)

  // ── GETTERS ────────────────────────────────────────────
  const { subdomain, mode, isTenant, isSuperAdminMode } = useOrganizationContext()

  const displayName = computed(() => current.value?.brandName ?? current.value?.name ?? 'LORA')
  const primaryColor = computed(() => current.value?.primaryColor ?? '#0071E3')
  const logoUrl = computed(() => current.value?.logoUrl ?? null)
  const hasActiveOrg = computed(() => current.value !== null && current.value.active === true)

  // ── ACTIONS ────────────────────────────────────────────

  /**
   * Carga la organización basada en el subdomain actual.
   * Se llama una sola vez al arrancar la app.
   *
   * Casos:
   *   - mode='tenant' (ej: jab.lorachat.net): carga la org por subdomain
   *   - mode='super-admin' (admin.lorachat.net): no carga nada, current=null
   *   - mode='unknown' (localhost): no carga nada
   */
  async function loadFromSubdomain() {
    // Si no estamos en un tenant, no hay org que cargar
    if (!isTenant || !subdomain) {
      loaded.value = true
      return
    }

    loading.value = true
    error.value = null

    try {
      const { data, error: rpcError } = await supabase
        .rpc('get_org_by_subdomain', { p_subdomain: subdomain })
        .maybeSingle()

      if (rpcError) throw rpcError

      if (!data) {
        error.value = `La empresa "${subdomain}" no existe o está desactivada`
        current.value = null
      } else {
        current.value = {
          id: data.id,
          name: data.name,
          subdomain: data.subdomain,
          brandName: data.brand_name,
          primaryColor: data.primary_color ?? '#0071E3',
          logoUrl: data.logo_url,
          logoFullUrl: data.logo_full_url,
          active: data.active
        }
      }
    } catch (e) {
      console.error('[organization.store] Error cargando org:', e)
      error.value = e instanceof Error ? e.message : 'Error desconocido'
      current.value = null
    } finally {
      loading.value = false
      loaded.value = true
    }
  }

  /**
   * Aplica el color primario al DOM como CSS variables.
   * Se llama después de loadFromSubdomain.
   * Otros componentes pueden referenciar var(--tenant-primary)
   * para branding dinámico.
   */
  function applyBrandingToDOM() {
    if (typeof document === 'undefined') return
    const color = primaryColor.value
    document.documentElement.style.setProperty('--tenant-primary', color)
    document.documentElement.style.setProperty('--tenant-primary-dark', darkenColor(color, 0.15))

    // También actualizar el title del documento con el brand
    if (current.value && isTenant) {
      document.title = `LORA · ${displayName.value}`
    }
  }

  /**
   * Helper: oscurece un hex por un factor (0-1).
   */
  function darkenColor(hex: string, factor: number): string {
    const h = hex.replace('#', '')
    let r = parseInt(h.substring(0, 2), 16)
    let g = parseInt(h.substring(2, 4), 16)
    let b = parseInt(h.substring(4, 6), 16)

    r = Math.round(r * (1 - factor))
    g = Math.round(g * (1 - factor))
    b = Math.round(b * (1 - factor))

    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`
  }

  /**
   * Limpia el store (útil en logout o testing).
   */
  function clear() {
    current.value = null
    error.value = null
    loaded.value = false
  }

  return {
    // state
    current,
    loading,
    error,
    loaded,
    // getters
    subdomain,
    mode,
    isTenant,
    isSuperAdminMode,
    displayName,
    primaryColor,
    logoUrl,
    hasActiveOrg,
    // actions
    loadFromSubdomain,
    applyBrandingToDOM,
    clear
  }
})
