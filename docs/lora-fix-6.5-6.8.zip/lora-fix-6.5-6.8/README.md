# 🔧 Sprint 6.5 + 6.8 — Fixes críticos

**Paquete único con 2 fixes urgentes:**

- **Sprint 6.5:** Aislamiento multi-tenant (super_admin en modo soporte veía datos de su propia org)
- **Sprint 6.8:** Error PGRST201 en UsersView (FK ambigua entre users y user_roles)

---

## 📋 Archivos incluidos (11 total)

| Ruta | Sprint | Cambios |
|---|---|---|
| `src/composables/useActiveOrganizationId.ts` | 6.5 | 🆕 Composable central |
| `src/repository/supabase/user.repo.ts` | 6.8 | 🔧 Fix FK ambigua |
| `src/modules/inbox/views/InboxView.vue` | 6.5 | 🔧 Usa activeOrgId |
| `src/modules/agents/views/UsersView.vue` | 6.5 | 🔧 Usa activeOrgId |
| `src/modules/agents/views/InvitationsView.vue` | 6.5 | 🔧 Usa activeOrgId |
| `src/modules/agents/views/AuditLogView.vue` | 6.5 | 🔧 Usa activeOrgId |
| `src/modules/reports/views/DashboardView.vue` | 6.5 | 🔧 Usa activeOrgId |
| `src/modules/knowledge/views/KnowledgeView.vue` | 6.5 | 🔧 Usa activeOrgId |
| `src/modules/ai/views/AiPersonasView.vue` | 6.5 | 🔧 Usa activeOrgId |
| `src/modules/playground/views/PlaygroundView.vue` | 6.5 | 🔧 Usa activeOrgId |
| `src/modules/channels/views/ChannelsView.vue` | 6.5 | 🔧 Usa activeOrgId |

**Todos los archivos ya tienen ruta completa desde `/src`**. Solo copia y reemplaza.

---

## 🔧 Instalación (todo en uno)

### Paso 1: Reemplazar archivos

Copia los 11 archivos a sus rutas correspondientes. Todos son reemplazos de archivos existentes excepto `useActiveOrganizationId.ts` que es nuevo.

### Paso 2: Probar en local

```powershell
npm run dev
```

### Paso 3: Test Sprint 6.5 (multi-tenant)

**Test A — Super admin en su propio panel:**
1. `.env.local`: `VITE_DEV_SUBDOMAIN=` (vacío)
2. Reiniciar dev server
3. Login como super_admin
4. Ir a Inbox → ver sus 17 conversaciones ✓
5. Ir a Usuarios → ver usuarios de Jab ✓

**Test B — Super admin en modo soporte:**
1. `.env.local`: `VITE_DEV_SUBDOMAIN=capitali`
2. Reiniciar dev server
3. Login como super_admin
4. Ver banner naranja "MODO SOPORTE" ✓
5. Ir a Inbox → **vacío** (Capitali no tiene conversaciones) ✓
6. Ir a Usuarios → solo CapitaliRD ✓
7. Ir a Dashboard → métricas de Capitali (no de Jab) ✓

### Paso 4: Test Sprint 6.8 (UsersView)

Con `VITE_DEV_SUBDOMAIN=` vacío y super_admin logueado:
1. Ir a Administración → Usuarios
2. **NO debe haber error `PGRST201` en consola** ✓
3. Debe mostrar la lista de usuarios con sus roles ✓

### Paso 5: Build

```powershell
npm run build
```

Si compila sin errores → deploy FTP.

---

## 🔍 Qué cambió exactamente

### Patrón del fix Sprint 6.5

**Antes (bug):**
```ts
const auth = useAuthStore()

async function load() {
  if (!auth.organizationId) return
  await repo.listX(auth.organizationId)  // ← siempre usa la org del USUARIO
}
```

**Ahora (fix):**
```ts
const auth = useAuthStore()
const activeOrgId = useActiveOrganizationId()  // ← NUEVO

async function load() {
  if (!activeOrgId.value) return
  await repo.listX(activeOrgId.value)  // ← usa la org del TENANT activo
}
```

El composable `useActiveOrganizationId()` resuelve:
- **Super_admin en modo soporte** → org del tenant visitado
- **Caso normal** → org del usuario logueado

### Patrón del fix Sprint 6.8

**Antes (bug):**
```ts
.select(`
  *,
  user_roles(role:roles(*))    // ← ambiguo: ¿qué FK?
`)
```

**Ahora (fix):**
```ts
.select(`
  *,
  user_roles!user_roles_user_id_fkey(role:roles(*))   // ← FK explícita
`)
```

---

## 📝 Commit sugerido

```bash
git add -A
git commit -m "fix(sprint-6.5+6.8): aislamiento multi-tenant y FK ambigua en users

Sprint 6.5 - Multi-tenant isolation:
- Nuevo composable useActiveOrganizationId() como fuente unica
  de verdad para el ID de org activo en contexto multi-tenant
- Aplicado en 9 views que filtran por organizacion:
  InboxView, UsersView, InvitationsView, AuditLogView,
  DashboardView, KnowledgeView, AiPersonasView,
  PlaygroundView, ChannelsView
- Logica: super_admin en modo soporte usa org del tenant,
  usuarios normales usan su propia org

Sprint 6.8 - Fix PGRST201 en UsersView:
- user_roles tiene 2 FKs hacia users (user_id y granted_by)
- Query ambigua no sabia cual usar
- Fix: especificar user_roles!user_roles_user_id_fkey explicitamente

Impact: super_admin en modo soporte ahora ve datos del tenant
correctamente aislados. UsersView funciona sin errores."

git push origin main
```

---

## ⚠️ Troubleshooting

### Después del fix, el inbox sigue vacío en modo soporte
✓ Correcto — la empresa visitada no tiene conversaciones. Prueba entrando a Jab (que sí tiene 17).

### Error en consola "Cannot read property 'organizationId' of null"
El usuario no está autenticado. Hacer logout + login de nuevo.

### El banner de modo soporte no aparece
Verifica que en .env.local está `VITE_DEV_SUBDOMAIN=capitali` (o similar) y reiniciaste el dev server.

### Build falla con error TS
Pégame el error, lo resolvemos.

---

## 🎯 Próximo paso (después de deployar esto)

Según el roadmap reorganizado, el siguiente sprint es **7.5 — Contactos** (módulo vacío).

Pero primero valida en producción que estos 2 fixes funcionan correctamente.
