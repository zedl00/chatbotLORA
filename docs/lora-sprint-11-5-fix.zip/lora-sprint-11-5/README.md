# 🔧 Sprint 11.5 FIX — Channels Dashboard

Corrige bugs y responde preguntas del Sprint 11.5 anterior.

---

## 🐛 Fixes aplicados en esta versión

### Fix 1: Error "uuid undefined" al abrir Configurar ✅
**Causa:** código usaba `channel.id` pero el tipo `ChannelMetrics` expone `channelId`.
**Arreglado en:** `ChannelCard.vue` — 2 líneas (`goToConfig` y snippet).

### Fix 2: Botón "Copiar código" expandido ✅
Ahora es un dropdown con 3 opciones:
- 📋 Código HTML completo (para sitio web)
- 🔑 Solo Channel ID (para código React/Vue)
- 🔗 Solo URL del widget.js

### Fix 3: SQL para eliminar duplicados ✅
`cleanup_duplicate_channels.sql` con verificaciones de seguridad.

---

## 🔐 Sobre el anon key (importante entender)

**El snippet NO expone la anon key.** Solo muestra:
- Channel ID (público por diseño)
- URL del widget.js (pública)

La anon key está dentro de `widget.js`. Eso **está bien y es estándar**:

| Key | ¿Exponer? |
|---|---|
| **anon key** | ✅ Sí, es pública por diseño |
| **service_role** | ❌ NUNCA |

La anon key está limitada por **Row Level Security (RLS)**. Un atacante con tu anon key **no puede hacer nada** que RLS no permita. Es la misma práctica de Intercom, Tidio, LiveChat.

### Si aún quieres ocultarla más:
- **Opción A (recomendada):** dejar como está — es seguro
- **Opción B:** crear proxy Edge Function (overkill)
- **Opción C:** ofuscar con base64 (falsa seguridad)

Mi recomendación: **Opción A**. Usa el tiempo en features que tu cliente vea.

---

## 📦 Archivos (10 — 1 más vs Sprint 11.5 original)

| Archivo | Cambio |
|---|---|
| `supabase/migrations/2026_sprint_11_5.sql` | = igual |
| `supabase/migrations/cleanup_duplicate_channels.sql` | 🆕 para limpiar duplicados |
| `src/types/channel.types.ts` | = igual |
| `src/repository/supabase/channels.repo.ts` | = igual |
| `src/modules/channels/views/ChannelsView.vue` | = igual |
| **`src/modules/channels/components/ChannelCard.vue`** | 🔧 FIX uuid + dropdown copiar |
| `src/modules/channels/components/ChannelActionsMenu.vue` | = igual |
| `src/modules/channels/components/CreateChannelModal.vue` | = igual |
| `src/modules/channels/components/EmptyChannelsState.vue` | = igual |
| `src/modules/channels/components/help/ChannelsHelpPanel.vue` | = igual |

**En la práctica, solo necesitas reemplazar `ChannelCard.vue`** (si ya aplicaste el Sprint 11.5). Los demás no cambian.

---

## 🚀 Orden de aplicación

### 1️⃣ Reemplazar `ChannelCard.vue` (única cambio crítico)

Copia el archivo `src/modules/channels/components/ChannelCard.vue` del ZIP a tu proyecto.

### 2️⃣ Build

```powershell
npm run build
```

Si pasa sin errores → continúa.

### 3️⃣ Verificar fix local

```powershell
npm run dev
```

- `/admin/channels` → click **⚙️ Configurar**
- ✅ **URL correcta:** `/admin/channels/widget/033fd98f-be93...`
- ✅ **YA NO error** de "uuid undefined"

### 4️⃣ Limpiar duplicados con SQL ⭐

Supabase → SQL Editor → pega `cleanup_duplicate_channels.sql` → Run.

El script tiene 3 pasos:
1. **Verifica** antes
2. **Borra** condicional (solo si 0 convs)
3. **Confirma** después

**Resultado esperado:**
```
Paso 1: muestra los 2 duplicados con total_conversations = 0
Paso 2: DELETE devuelve 2 filas (los 2 eliminados)
Paso 3: queda solo el "Widget Web (playground)" con sus 67 convs
```

### 5️⃣ Probar dropdown copiar

Vuelve a `/admin/channels` → click **📋 Copiar** en un canal:
- Dropdown aparece con 3 opciones
- Prueba cada una → toast confirma qué se copió

### 6️⃣ Commit + Deploy

```bash
git add -A
git commit -m "fix(sprint-11.5): uuid undefined en WidgetConfig + dropdown copiar

FIX: channel.id -> channel.channelId en ChannelCard
(error 'invalid input syntax for type uuid undefined' al abrir Configurar)

FEATURE: Dropdown copiar con 3 opciones
- Codigo HTML completo
- Solo Channel ID
- Solo URL del widget.js

SQL: cleanup_duplicate_channels.sql para limpieza segura de canales vacios"

git push

# Build final + FTP
npm run build
# CoreFTP: /public_html/lora/ → borrar → subir dist/
```

---

## 🧪 Tests esperados después

### Test 1 — Post-limpieza
- Solo 1 canal visible: "Widget Web (playground)" con 67 convs
- Stats: Total 1, Activos 1, Conversaciones 67

### Test 2 — Configurar funciona
- Click ⚙️ Configurar
- ✅ URL va a widget config real
- ✅ **NO error uuid undefined**
- Carga WidgetConfigView con 4 tabs

### Test 3 — Dropdown copiar
- Click 📋 Copiar → 3 opciones
- Cada opción copia el texto correcto
- Toast muestra qué se copió

### Test 4 — Crear canal nuevo
- + Crear canal → wizard 3 pasos
- Después de crear, navega a su config

---

## 💾 Después de FTP

Prueba en producción:
```
https://lora.jabenter.com/admin/channels
```

1. Ves 1 canal
2. Click Configurar → abre sin error
3. Dropdown Copiar tiene 3 opciones

Cuando confirmes que funciona → arrancamos Sprint 12.

---

## 🎯 Siguiente sprint

**Sprint 12 — Help System framework + docs retroactivas**
- Crear sistema de Help reutilizable (HelpButton + HelpPanel globales)
- Archivos de contenido por pantalla (md/json)
- Documentar retroactivamente: Analytics, SLA Config, Inbox, Quick Replies, Contactos, Dashboard
- Tour guiado opcional primera vez

Estimado: 2-3 horas.
