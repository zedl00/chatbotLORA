# 🔧 FIX BUILD — channel.types.ts merged

Este ZIP resuelve los 17 errores del build reemplazando UN solo archivo.

---

## 🎯 Lo que hace

Reemplaza `src/types/channel.types.ts` con una versión que tiene **TODO**:

✅ Preserva lo que tu código ya usa:
- `Contact` (para ContactFormModal, ContactsView, etc.)
- `ChannelType` con `'sms'` incluido (para utils/constants.ts)
- `Channel` con `credentials`, `webhookUrl`, `webhookSecret`, `externalId`, `lastError`, `lastErrorAt`, `settings`, `defaultPersonaId` (para channel.repo.ts)
- `CreateChannelInput` con todos los campos opcionales
- `UpdateChannelInput` para los updates

✅ Agrega lo nuevo del Sprint 11.5:
- `ChannelMetrics` (vista de métricas)
- `ChannelTypeMetadata` (para CHANNEL_TYPES)
- `CHANNEL_TYPES[]` (con SMS incluido)
- `getChannelMetadata()`
- `timeSince()`

---

## 🚀 Aplicar

### 1️⃣ Reemplaza UN solo archivo

```
src/types/channel.types.ts
```

Con el del ZIP. No toques nada más.

### 2️⃣ Build

```powershell
npm run build
```

**Debería pasar sin errores.** Si sale alguno nuevo, es porque hay algún campo que yo no cubrí (los errores anteriores no lo mencionaron). En ese caso, pégame el error exacto y lo agrego.

---

## 🔍 Posibles errores remanentes (poco probables)

Si aparece algo tipo:
```
'someField' does not exist on type 'Channel'
```

Significa que tu `channel.repo.ts` usa un campo que yo no puse. Son fáciles de agregar. Pégame el error.

---

## 📘 Política nueva (desde ahora)

Para que esto NO vuelva a pasar:

### Regla 1 — No toco tipos compartidos sin verlos primero
Si un sprint modifica `/types/`, `/utils/`, `/stores/` o `/composables/`, te pido el archivo actual ANTES de escribir código nuevo.

### Regla 2 — Merge, no reemplazo
Cuando agrego cosas a archivos compartidos, entrego el cambio como:
- "**Agrega esto** después de la línea X"
- Y te muestro el diff exacto

Nunca más "reemplaza este archivo completo" para archivos compartidos.

### Regla 3 — Mini-checklist al final de cada sprint
Antes de empaquetar ZIP, me hago estas preguntas:
- ¿Tocamos archivos en `/types/`, `/utils/`, `/stores/`, `/composables/`?
- ¿Sabemos qué otros módulos importan de ahí?
- ¿Los imports cambiaron de nombre o ubicación?

Si hay riesgo → entregas parches quirúrgicos, no reemplazos.

### Regla 4 — Cuando rompa algo, lo reparo sin preguntar
Si yo rompí el build, yo lo arreglo con lo que pueda inferir. No te voy a pedir archivos cada vez que haya un error mío.

---

## ⏱️ Tu tiempo NO se está perdiendo

Aunque se sienta frustrante, esta situación pasa en TODO desarrollo real. La diferencia es que:

- En equipos grandes → aparece en PR review o CI antes de merge
- En solo dev → aparece en el build local

**Por eso el build local es tu amigo:** cacha errores antes de que vayan a producción. Cada error que el build detecta = 1 bug menos en prod.

La política de arriba reduce la frecuencia, pero no elimina el 100% porque la base de código crece y las interdependencias también.

---

## 🎯 Después del fix

```powershell
npm run build  # debe pasar ✅
npm run dev    # prueba local
```

Si ya pasa:
1. Prueba los canales en `/admin/channels`
2. Prueba abrir Configurar (debe funcionar ya sin el error uuid)
3. Prueba el dropdown Copiar
4. Corre el SQL de limpieza de duplicados si quieres

Y listo para commit + deploy.
