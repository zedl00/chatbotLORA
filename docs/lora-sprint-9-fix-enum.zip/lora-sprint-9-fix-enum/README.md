# 🔧 Fix SQL Sprint 9 — sender_type es enum, no text

## 🐛 Qué pasó

Tu `sender_type` es un **ENUM** de PostgreSQL (no text libre como pensé).

El SQL original intentaba crear un CHECK constraint:
```sql
CHECK (sender_type IN ('contact', 'agent', 'bot', 'whisper', 'system'))
```

Eso **falla** porque PostgreSQL valida el enum ANTES del CHECK, y "whisper" no existe como valor del enum.

## 🔍 Cómo lo descubrí

El primer diagnóstico falló porque:
- `SELECT unnest(enum_range(NULL::sender_type_enum))` → error "type does not exist"
- Eso me hizo pensar que no era enum
- Pero en realidad se llama `sender_type` (no `sender_type_enum`)

El error real:
```
invalid input value for enum sender_type: "whisper"
```

Confirma que **SÍ es enum**, solo con nombre diferente al esperado.

## ✅ Fix

Agregar los valores nuevos al enum existente:
```sql
ALTER TYPE sender_type ADD VALUE IF NOT EXISTS 'whisper';
ALTER TYPE sender_type ADD VALUE IF NOT EXISTS 'system';
```

## 🚀 Aplicación

### Paso 1: Corre este SQL PRIMERO

Supabase → SQL Editor → **Nueva Query** → pega `2026_sprint_9_fix_enum.sql` → Run.

⚠️ **No uses "Run in transaction"** ni envuelvas con BEGIN/COMMIT.  
`ALTER TYPE ADD VALUE` necesita correr fuera de transacción.

**Verifica al final:**
```
sender_type_values : contact, agent, bot, whisper, system
```

### Paso 2: Ahora corre el SQL original del Sprint 9

Vuelve a `2026_sprint_9.sql` y córrelo completo.

El bloque del CHECK constraint ya no fallará (porque los valores ahora existen en el enum, y el constraint se eliminará antes gracias al DROP IF EXISTS).

**O MÁS LIMPIO**: salta ese bloque. Con el enum ya teniendo los valores, no necesitas el CHECK.

Si prefieres saltarlo, busca en el SQL original esta sección y bórrala:

```sql
-- ─────────────────────────────────────────────────────────────
-- 1. sender_type — agregar valores válidos (si no es enum)
-- ... (todo el bloque DO $$ ... END $$)
```

### Paso 3: Resto del Sprint 9 (SQL + frontend)

Continúa aplicando lo que ya estaba:
- Tabla `sla_configs` ✅
- Tabla `escalations` ✅
- 4 RPCs ✅
- Permisos ✅
- Cron ✅

Y luego los 12 archivos de frontend del ZIP de Sprint 9.

## ✨ Por qué ALTER TYPE necesita estar fuera de transacción

Esto es una quirk de Postgres: los valores nuevos de un enum agregados con `ALTER TYPE ADD VALUE` no están disponibles para usar dentro de la misma transacción donde se agregaron.

Por eso el `DO $$ ... END $$` block del SQL original falla incluso si ponemos los `ALTER TYPE` al principio: todo el bloque es una transacción implícita.

**Solución:** statements separados, cada uno corriendo como transacción individual.

## 📝 Actualización al SQL del Sprint 9

Para que no vuelvas a tener el problema, aquí va el bloque correcto para reemplazar en `2026_sprint_9.sql`:

**Borrar completamente** la sección:
```sql
-- 1. sender_type — agregar valores válidos (si no es enum)
-- ... hasta el END $$
```

**Reemplazar con**: nada. Ya no es necesario — los valores ya están en el enum después de este fix.

## 🎯 Orden correcto final

1. ✅ **Corre este fix**: `2026_sprint_9_fix_enum.sql`
2. ✅ **Corre el SQL original** del Sprint 9 (puedes correrlo completo, el bloque 1 ya no fallará porque el DROP IF EXISTS lo hace defensivo, aunque técnicamente no hace nada útil ahora)
3. ✅ **Copia los 12 archivos de frontend**
4. ✅ **`npm run build`** y **`npm run dev`**
5. ✅ **Testear con los 10 tests del README**
