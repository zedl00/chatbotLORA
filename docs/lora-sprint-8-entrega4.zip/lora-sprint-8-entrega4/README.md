# 💬 Sprint 8 — Entrega 4: Quick Replies + Historial en Inbox

Entrega final del **paquete Agent Workspace**. Completa la Entrega 3 con:

1. **CRUD completo de Quick Replies** (snippets personales y compartidos)
2. **Invocación con `/shortcut`** en el editor de chat (tipo Slack)
3. **Botón "📚 Snippets"** visible en el editor
4. **Historial mini del contacto** en el panel derecho del Inbox
5. **Cron pg_cron** para auto-away server-side

---

## 📦 Archivos incluidos (10)

| Ruta | Tipo | Descripción |
|---|---|---|
| `supabase/migrations/2026_sprint_8_entrega4.sql` | 🆕 Migración | Permisos + RPC + cron |
| `src/stores/quick-reply.store.ts` | 🆕 Store | Estado global de snippets |
| `src/modules/agents/views/QuickRepliesView.vue` | 🆕 Vista | CRUD con tabs |
| `src/modules/agents/components/QuickReplyModal.vue` | 🆕 Componente | Crear/editar modal |
| `src/modules/inbox/components/QuickReplyDropdown.vue` | 🆕 Componente | Dropdown con `/` |
| `src/modules/inbox/components/QuickReplyButton.vue` | 🆕 Componente | Botón + modal lista |
| `src/modules/inbox/components/ConversationThread.vue` | 🔧 Reemplazar | Integración dropdown + botón |
| `src/modules/inbox/components/ContactPanel.vue` | 🔧 Reemplazar | Sección Últimas conversaciones |
| `src/layouts/AdminLayout.vue` | 🔧 Reemplazar | Menú "Respuestas rápidas" |
| `src/router/index.ts` | 🔧 Reemplazar | Ruta `/admin/quick-replies` |

---

## 🚀 Aplicación (orden importante)

### Paso 1: Aplicar SQL

Abre Supabase Dashboard → SQL Editor → New Query → pega `supabase/migrations/2026_sprint_8_entrega4.sql` → Run.

**Verifica** que al final veas:

```
permisos_quick_replies   | 5 | quick_replies.create, quick_replies.delete, quick_replies.read, quick_replies.share, quick_replies.update
rpc_increment_usage      | true
role_permissions_asignados | >= 13   (agent: 4, supervisor: 5, admin: 5)
cron_programado          | true  o  false  (ver nota abajo)
```

#### ⚠️ Sobre pg_cron

Si `cron_programado = false`, significa que **pg_cron no está habilitado** en tu instancia Supabase. Esto no bloquea nada — el sistema sigue funcionando, pero el auto-away no correrá server-side.

**Para habilitarlo:**
1. Dashboard → Database → Extensions
2. Buscar "pg_cron"
3. Click "Enable extension"
4. Volver a correr el bloque del cron al final de la migración

Si tu plan de Supabase no soporta pg_cron, ignora y sigue. El auto-away sigue funcionando cuando el agente tiene la app abierta (client-side).

---

### Paso 2: Copiar los 9 archivos de frontend

Todos vienen con ruta completa desde `/src` o `/supabase`. Respeta la estructura.

### Paso 3: Build

```powershell
npm run build
```

Debe pasar sin errores. Si aparece alguno, pégamelo.

### Paso 4: Dev

```powershell
npm run dev
```

### Paso 5: Probar (orden recomendado)

#### Test A — Permisos correctos

1. Login como super_admin
2. Debes ver en el sidebar: **Configuración → Respuestas rápidas**
3. Entra: `/admin/quick-replies`
4. Ves la vista vacía con botón "+ Nuevo snippet"

#### Test B — Crear snippet personal

1. Click "+ Nuevo snippet"
2. Shortcut: `saludo`
3. Título: `Saludo inicial`
4. Contenido: `¡Hola! 👋 Bienvenido/a. ¿En qué puedo ayudarte?`
5. Categoría: 👋 Saludo
6. Visibilidad: **Solo para mí** (deja el toggle off)
7. Click "Crear snippet"
8. **Esperado:** toast verde, modal cierra, aparece en tab "Mis snippets"

#### Test C — Crear snippet compartido

1. Click "+ Nuevo snippet"
2. Shortcut: `despedida`
3. Contenido: `¡Gracias por contactarnos! Que tengas excelente día ✨`
4. Toggle **"Compartido con el equipo"** → ON (como admin/super_admin puedes)
5. Guardar
6. **Esperado:** aparece en tab "Compartidos del equipo" con badge verde "COMPARTIDO"

#### Test D — Dropdown con `/` en chat

1. Ve al Inbox, abre cualquier conversación asignada
2. En el textarea, escribe: `/`
3. **Esperado:** aparece dropdown con todos los snippets (máx 10)
4. Sigue escribiendo: `/sal` → se filtra a los que empiezan con "sal"
5. Usa flecha ↓ para navegar
6. Enter para seleccionar "/saludo"
7. **Esperado:** el textarea se llena con el contenido del snippet
8. Dropdown se cierra

#### Test E — Botón 📚 Snippets

1. En el mismo editor del Inbox
2. Click en botón "📚 Snippets" (a la derecha del textarea)
3. Se abre un modal flotante con barra de búsqueda
4. Escribe en el search
5. Click en un snippet → se inserta en el editor en la posición del cursor

#### Test F — Usage counter

1. Usa el snippet "/saludo" 3 veces (insertar en distintas conversaciones)
2. Ve a `/admin/quick-replies`
3. **Esperado:** "/saludo" dice "Usado 3 veces"

#### Test G — Permiso: agente NO puede compartir

1. Crea un usuario con role `agent`
2. Login como ese usuario
3. Ve a Quick Replies → click "+ Nuevo snippet"
4. **Esperado:** el toggle "Compartido con el equipo" está **deshabilitado**
5. Mensaje: "Solo supervisores y admins pueden crear snippets compartidos"

#### Test H — Historial mini en ContactPanel

1. Abre un contacto que tenga 2+ conversaciones en el Inbox
2. Panel derecho: sección "📜 Últimas conversaciones"
3. Ves las otras conversaciones (no la actual) con: asunto, fecha relativa, agente, CSAT, estado
4. Click en una → navega a `/admin/contacts/:id` (perfil del contacto)

#### Test I — Contacto sin historial

1. Abre un contacto que solo tiene 1 conversación (la actual)
2. Sección dice: "Esta es su primera conversación con nosotros ✨"

#### Test J — Tab compartidos con varios usuarios

1. Login con usuario A → crea snippet compartido
2. Logout
3. Login con usuario B (mismo tenant)
4. Ve a `/admin/quick-replies` → tab "Compartidos"
5. **Esperado:** ve el snippet compartido del usuario A
6. Si el user B tiene permiso `quick_replies.share`, puede editarlo
7. Si no lo tiene, solo puede verlo

---

## 🔐 Matriz de permisos

| Rol | read | create | update | delete | share |
|---|---|---|---|---|---|
| agent | ✅ own | ✅ | ✅ own | ✅ own | ❌ |
| supervisor | ✅ team | ✅ | ✅ team | ✅ team | ✅ |
| admin | ✅ all | ✅ | ✅ all | ✅ all | ✅ |
| super_admin | ✅ * (wildcard) | ✅ | ✅ | ✅ | ✅ |

**Explicación:**
- `read own`: ve solo los propios + los compartidos de la org
- `read team`: lo mismo (no hay concepto de "team scope" para snippets, `team` = `all` en la práctica)
- `read all`: idem

---

## ⚠️ Limitaciones conocidas

### 1. El historial del ContactPanel no abre la conversación específica
Al hacer click, te lleva a `/admin/contacts/:id` (perfil del contacto). En un sprint futuro podemos agregar `?conversationId=X` para abrir directamente la conversación en el Inbox.

### 2. Variables dinámicas en snippets
Actualmente los snippets son texto plano. Ideas para el futuro:
- `{{contact.name}}` → inserta nombre del contacto
- `{{agent.name}}` → inserta nombre del agente
- `{{date}}` → fecha actual

Esto sería un sprint separado.

### 3. Sharing "por equipo"
Las compartidas son globales a la org. No hay scope por equipo. Si necesitas snippets solo para el equipo de Ventas vs Soporte, lo hacemos en sprint futuro.

### 4. Búsqueda en dropdown solo por shortcut
El dropdown con `/` solo filtra por el shortcut que empieza con el prefix. No busca en el título o contenido. El botón "📚 Snippets" sí hace búsqueda completa.

### 5. pg_cron puede no estar disponible
En planes free o sin pg_cron habilitado, el auto-away solo funciona client-side. Si alguien cierra el navegador bruscamente, se queda "online" hasta que alguien refresque la vista de Equipo (el componente recarga cada 30s).

---

## 💾 Commit sugerido

```bash
git add -A
git commit -m "feat(sprint-8-entrega4): Quick Replies + Historial contacto

- 5 permisos nuevos: quick_replies.read/create/update/delete/share
  Asignados a roles agent (básicos own), supervisor (+share team),
  admin (+share all).
- Store Pinia para compartir data entre vista y editores.
- QuickRepliesView: CRUD con tabs Mis snippets / Compartidos
- Integración en ConversationThread:
  * Botón 'Snippets' visible en toolbar
  * Dropdown con '/' autocompletado
  * Usage counter se incrementa al insertar
- ContactPanel: sección 'Últimas conversaciones' con historial mini
- Menú 'Respuestas rápidas' en sidebar
- pg_cron job cada 2 min para auto_away(5) server-side"
```

---

## 🐛 Troubleshooting

### "Column quick_replies.is_shared does not exist"
La tabla `quick_replies` se creó en Entrega 1 pero tal vez tiene otro nombre de columna. Corre:
```sql
SELECT column_name FROM information_schema.columns WHERE table_name = 'quick_replies';
```
Si la columna es diferente, pégame el output y adapto el código.

### "Permission denied for relation quick_replies"
Las RLS policies no se aplicaron. Corre esto:
```sql
SELECT policyname FROM pg_policies WHERE tablename = 'quick_replies';
```
Si devuelve 0 filas, necesitamos reaplicar las policies de la Entrega 1.

### El menú "Respuestas rápidas" no aparece
Tu usuario no tiene el permiso `quick_replies.read`. Corre:
```sql
SELECT user_id, permission_id, p.key
FROM user_roles ur
JOIN role_permissions rp ON rp.role_id = ur.role_id
JOIN permissions p ON p.id = rp.permission_id
WHERE p.key LIKE 'quick_replies%' AND ur.user_id = 'tu-user-id';
```
Debería devolver filas. Si no, verifica que el SQL de permisos se aplicó.

### Error "duplicate key value violates unique constraint"
Intentaste crear un snippet con un shortcut que ya existe (tuyo o compartido de la org). La UI ya captura este error y te muestra un mensaje.

### El cron no corre
Si tienes pg_cron pero no ves el cron ejecutándose:
```sql
SELECT * FROM cron.job WHERE jobname = 'lora_auto_away_agents';
SELECT * FROM cron.job_run_details ORDER BY start_time DESC LIMIT 5;
```
La segunda query te muestra las últimas ejecuciones y errores si hubo.

### TS errors en build
Probables causas y soluciones:
- `Cannot find module '@/types/agent.types'`: los tipos ya los creaste en Entrega 1. Verifica que `QUICK_REPLY_CATEGORIES` esté exportado.
- `Cannot find module 'quick-reply.repo'`: el repo ya existe (Entrega 1). Verifica `SupabaseQuickReplyRepo`.
- Si aparece otro, pégamelo.

---

## 🎯 Sprint 8 COMPLETO ✅

Con esta entrega termina el paquete Agente:

- ✅ Entrega 1: SQL foundation (tablas, RPCs, vista, tipos)
- ✅ Entrega 2: Contactos admin (CRUD + detalle + historial)
- ✅ Entrega 3: Agent Presence (heartbeat + badge + AgentsView)
- ✅ Entrega 4: Quick Replies + historial en Inbox

## 🚀 Siguientes Sprints

**Sprint 9 — Supervisor Tools** (1-2h):
- Takeover de conversaciones (supervisor puede "tomar" de un agente)
- Whisper (notas privadas visibles solo al agente durante conversación)
- Escalamientos automáticos si SLA se pasa

**Sprint 10 — Agent Analytics** (1h):
- Métricas por agente: conversaciones resueltas, FRT, CSAT
- Leaderboard semanal
- Exportable a CSV

**Sprint 11 — Settings completo** (30 min):
- Auto-respuestas fuera de horario
- Configuración de SLA
- Notificaciones (email/push)

¿Con cuál seguimos? 🎯
