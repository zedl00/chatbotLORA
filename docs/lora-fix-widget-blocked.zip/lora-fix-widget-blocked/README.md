# 🚫 Fix B — Bloqueo funcional de contactos en el widget

## 🎯 Qué hace

Cuando un agente bloquea un contacto desde `/admin/contacts/:id`, el widget ahora **realmente rechaza** los mensajes de ese contacto con un 403.

## 📦 Archivo

- `supabase/functions/widget-message/index.ts` — reemplazar

## 🚀 Aplicación

### Opción A: Deploy desde Supabase CLI (recomendado si usas git)

```bash
# Desde la raíz del proyecto
cd C:\xampp\htdocs\proyectos\chatbot
# Copia el archivo a supabase/functions/widget-message/
supabase functions deploy widget-message
```

### Opción B: Deploy desde Dashboard (si no tienes CLI)

1. Abre el archivo nuevo (`supabase/functions/widget-message/index.ts`) y copia todo el contenido
2. Ve a Supabase Dashboard → Edge Functions → `widget-message`
3. Click en "Edit" o en el código visible
4. Borra todo y pega el nuevo contenido
5. Click "Deploy"

## 🧪 Cómo probar

### Test 1: Escribir normal (no bloqueado)

1. Ve al widget embebido (tu sitio de prueba)
2. Envía mensaje: "Hola"
3. **Esperado:** recibe respuesta del bot normalmente

### Test 2: Bloquear un contacto

1. Abre `/admin/contacts`
2. Click en un contacto que tenga una conversación por widget
3. Click "🚫 Bloquear contacto"
4. Toast de confirmación

### Test 3: Intentar escribir desde un contacto bloqueado

1. Regresa al widget del sitio de prueba (misma sesión del contacto bloqueado)
2. Intenta enviar un mensaje
3. **Esperado:**
   - El mensaje NO aparece en el chat
   - Error 403 en consola del navegador
   - Response body: `{ error: 'contact_blocked', message: '...' }`

### Test 4: Desbloquear y escribir de nuevo

1. `/admin/contacts/:id` → "✓ Desbloquear contacto"
2. Volver al widget
3. Enviar mensaje
4. **Esperado:** funciona normal de nuevo

## ⚠️ Limitaciones conocidas

### El widget actual no muestra un mensaje UX al bloquear

Actualmente al recibir el 403, el widget simplemente falla en silencio o muestra un error técnico. **Mejora UX pendiente** para el siguiente sprint del widget:

- Mostrar un toast: "No podemos procesar tu mensaje en este momento."
- Deshabilitar el input
- O redirigir a un formulario de contacto alternativo

Por ahora: el bloqueo **funciona a nivel de seguridad** (no se crean mensajes en BD), pero la UX del widget no es linda. Priorizamos seguridad.

### Solo aplica al widget web

Este fix cubre `widget-message`. Cuando implementemos Telegram, WhatsApp, etc., cada edge function tendrá que hacer el mismo check. Lo pongo en el backlog del sprint correspondiente.

### Contacto bloqueado aún puede crear sesión

El endpoint `widget-session` (que crea la sesión inicial) no verifica bloqueo. **Esto es intencional** porque:
- La sesión se crea en el primer load del widget, antes de saber quién es la persona
- Solo cuando intenta enviar mensaje sabemos qué contacto es
- El bloqueo se aplica en `widget-message` que sí tiene el `contact_id`

## 💾 Commit sugerido

```bash
git add -A
git commit -m "feat(sprint-7.5): bloqueo funcional de contactos en widget

widget-message edge function ahora verifica contacts.blocked
antes de crear el mensaje. Si el contacto esta bloqueado,
retorna 403 y no crea registros en BD.

Cierra la feature de bloqueo que antes solo era cosmetica
(solo marcaba el flag sin efecto real)."
```

## ✅ Checklist de entrega

- [ ] Archivo copiado a `supabase/functions/widget-message/index.ts`
- [ ] Deploy via CLI o Dashboard
- [ ] Test 1 (normal) pasa
- [ ] Test 3 (bloqueado) responde 403
- [ ] Test 4 (desbloqueo) vuelve a funcionar
