# CONTEXT.md — ChatBot IA Empresarial

> **Ruta:** `/CONTEXT.md`
> **Propósito:** Fuente de verdad sobre la visión, estado actual y decisiones del proyecto.
> **Mantener:** Actualizar al cierre de cada sprint y al tomar decisiones técnicas importantes.

---

## 📌 Identidad del Proyecto

| Campo | Valor |
|---|---|
| **Nombre** | ChatBot IA Empresarial Omnicanal |
| **Versión actual** | 0.2.0 (RBAC Enterprise) |
| **Fase actual** | Fase 0 — Setup + RBAC |
| **Sprint activo** | Sprint 2.5 — Módulo RBAC Enterprise completado |
| **Fecha de inicio** | 2026-04-21 |
| **Stack principal** | Vue 3 + Vite + TS + Tailwind + Pinia + Supabase + Claude API |

---

## 🎯 Visión

Desarrollar un ChatBot empresarial omnicanal de clase mundial, con inteligencia artificial (Claude de Anthropic) como primera línea de atención, capaz de operar sobre múltiples canales (WhatsApp, Instagram, Messenger, Telegram, Widget Web), con panel administrativo en tiempo real, handoff a agentes humanos, métricas de rendimiento, **control de acceso empresarial granular (RBAC)**, y arquitectura intercambiable de base de datos.

## 🧭 Principios Arquitectónicos (No Negociables)

1. **Repository Pattern obligatorio** — Ningún componente o store llama a Supabase directamente. Todo pasa por `src/repository/`.
2. **Channel Adapter Pattern** — Todos los canales implementan la misma interfaz `ChannelAdapter`.
3. **RLS como primera línea de defensa** — Supabase Row Level Security en TODAS las tablas.
4. **RBAC en backend + frontend** — `has_permission()` en RLS + `v-can` / `useCan()` en UI. Nunca confiar solo en el cliente.
5. **TypeScript estricto** — `strict: true` en `tsconfig.json`.
6. **Separación Cliente/Servidor de secretos** — Variables `VITE_*` solo para claves públicas. Secretos del servidor van en Edge Functions.
7. **Conventional Commits** sin excepción.
8. **Componentes < 300 líneas**. Si crecen, se dividen.
9. **No instalar librerías nuevas sin aprobación del dueño del proyecto**.

## 👥 Sistema de Roles y Permisos (RBAC Enterprise)

A partir de v0.2.0 el sistema usa **RBAC granular** en vez de roles fijos hardcoded:

### Roles del sistema (preconstruidos, no eliminables)
- **Super Admin** — Todos los permisos (wildcard)
- **Admin** — Todos excepto `billing.manage`, `users.delete`, `roles.delete`
- **Supervisor** — `*.team` sobre conversaciones, métricas y reportes de su equipo
- **Agente** — `*.own` sobre sus propias conversaciones
- **Viewer** — Solo lectura de dashboards y reportes

### Roles personalizados
Cada organización puede crear roles propios combinando los 60+ permisos atómicos. Ejemplos: "Agente Senior", "Analista de Datos", "Entrenador de IA".

### Permisos atómicos (formato: `recurso.acción`)
Organizados por 13 categorías: Conversaciones, Mensajes, Notas, Contactos, Canales, Flujos IA, Base de Conocimiento, Equipo, Reportes, IA, Usuarios y Permisos, Configuración, Facturación.

### Resolución de permisos (orden)
1. **Deny explícito** en `user_permissions` (grant=false) → DENY siempre.
2. **Super admin** → ALLOW wildcard.
3. **Grant explícito** en `user_permissions` → ALLOW.
4. **Vía roles** asignados en `user_roles` (no expirados) → ALLOW si coinciden scope.
5. Por defecto → DENY.

### Scopes (para permisos `scopeable`)
- `own` — solo sus propios recursos
- `team` — recursos del/los equipo(s) asignados
- `all` — todos los recursos de la organización

### Features
- ✅ Múltiples roles por usuario
- ✅ Delegación temporal (roles con `expires_at`)
- ✅ Permisos a nivel de equipo (campo `team_id` en `user_roles`)
- ✅ Overrides directos por usuario (grant/deny)
- ✅ Invitación por email con token criptográfico
- ✅ Creación directa con contraseña temporal + force-change al primer login
- ✅ Auditoría detallada automática de todos los cambios

## 🔌 Canales a Integrar (por orden de prioridad)

1. **Widget Web** (en paralelo desde el inicio)
2. **WhatsApp Business** (Fase 1 - Core MVP)
3. **Instagram DM** (Fase 2)
4. **Messenger** (Fase 2)
5. **Telegram** (Fase 2)
6. **SMS / Twilio** (Fase 3)
7. **Email** (Fase 3)

## 🧠 Motor IA

- **Modelo principal:** `claude-sonnet-4-20250514`
- **Modelo de respaldo:** `claude-haiku-4-5-20251001`
- **Max tokens por respuesta:** 1000 (configurable por organización)

## 📊 Estado Actual del Desarrollo

### ✅ Completado
- [x] Definición de arquitectura
- [x] Prompt maestro aprobado
- [x] CONTEXT.md y CHANGELOG.md inicializados
- [x] Estructura de carpetas creada
- [x] Schema base de base de datos (14 tablas) + RLS + triggers
- [x] Scaffolding Vue 3 + Vite + Pinia + Tailwind + Supabase client
- [x] Capa Repository con patrón desacoplado
- [x] Login funcional, guards de router
- [x] Layouts base (Auth + Admin)
- [x] Edge Function meta-webhook (esqueleto)
- [x] **Módulo RBAC Enterprise completo** (v0.2.0):
  - [x] Schema RBAC: 7 tablas (permissions, roles, role_permissions, user_roles, user_permissions, invitations, audit log)
  - [x] Catálogo de 60+ permisos atómicos
  - [x] 5 roles del sistema preconfigurados
  - [x] Función `has_permission()` con resolución completa
  - [x] Migración automática de datos legacy
  - [x] 3 Edge Functions (invite, accept-invite, create)
  - [x] UI: UsersView, RolesView, InvitationsView, AuditLogView
  - [x] Composable `useCan` + directiva `v-can`
  - [x] Store `permissions.store` con caché O(1)
  - [x] Guard de rutas por permisos granulares

### 🚧 En Progreso
- [ ] Testing manual del flujo RBAC completo
- [ ] Migrar RLS legacy de `is_role_at_least()` a `current_user_has()` (gradual)

### ⏭️ Siguiente (Sprint 3)
- [ ] Webhook de WhatsApp recibiendo mensajes reales (sandbox Meta)
- [ ] Widget web embebible básico
- [ ] Pipeline mensaje → DB → realtime → inbox
- [ ] Primer bot respondiendo con Claude API

## 🗂️ Convenciones de Nombrado

- **Composables:** prefijo `use` → `useConversations.ts`, `useCan.ts`
- **Stores Pinia:** sufijo `Store` → `conversationsStore`, `permissionsStore`
- **Tipos:** sufijo `.types.ts` → `conversation.types.ts`, `rbac.types.ts`
- **Repositorios:** sufijo `.repo.ts` → `conversation.repo.ts`, `rbac.repo.ts`
- **Servicios externos:** sufijo `.service.ts` → `claude.service.ts`
- **Directivas:** archivos sin prefijo → `can.ts`, registrar con prefijo `v` → `v-can`
- **Componentes:** PascalCase → `AgentCard.vue`
- **Archivos de rutas:** kebab-case en URLs → `/admin/my-inbox`, `/auth/accept-invite`
- **Permisos:** snake_case con punto → `conversations.assign`, `users.invite`

## 📝 Decisiones Técnicas Registradas

| Fecha | Decisión | Razón |
|---|---|---|
| 2026-04-21 | Pinia sobre Vuex | Estándar oficial Vue 3, mejor soporte TS |
| 2026-04-21 | Supabase sobre Firebase | PostgreSQL + RLS + Edge Functions + Realtime nativo |
| 2026-04-21 | Claude Sonnet 4 sobre GPT-4o | Mejor balance costo/calidad para conversacional en español |
| 2026-04-21 | Vue Router + Guards por rol | Control de UX; RLS sigue siendo la defensa real |
| 2026-04-21 | Day.js sobre date-fns | Bundle size más liviano |
| 2026-04-22 | **RBAC Enterprise sobre roles fijos** | Permisos granulares, roles custom por org, delegación temporal — requisito explícito |
| 2026-04-22 | **Mantener `users.role` legacy** | Compatibilidad hacia atrás con código existente; marcar deprecated |
| 2026-04-22 | **Permisos cargados al login, cacheados en store** | Evitar N+1 en cada render; refresh explícito tras cambios |
| 2026-04-22 | **Resolución de permisos en DB (RPC)** | Single source of truth; frontend solo cachea el resultado |

## 🔗 Enlaces Importantes

- **Repositorio GitHub:** _(pendiente de crear)_
- **Notion del Proyecto:** _(pendiente de compartir)_
- **Supabase Project:** _(pendiente de crear)_
- **Staging URL:** _(pendiente)_
- **Producción URL:** _(pendiente)_

## ⚠️ Riesgos Conocidos

1. **Aprobación de Meta App Review** puede tardar semanas. Mitigación: Widget Web + Telegram en paralelo.
2. **Costos de Claude API** pueden escalar con volumen. Mitigación: límites por organización + modelo Haiku para clasificación.
3. **RLS mal configurado** = fuga de datos entre organizaciones. Mitigación: tests automatizados de RLS antes de producción.
4. **🆕 Policy pública de invitaciones expone tokens** — Mitigación: tokens son 32 bytes aleatorios (256-bit entropy); computacionalmente infeasible adivinar.
5. **🆕 Super admin puede auto-perjudicarse** — No hay política que impida a un super_admin quitarse sus propios permisos. Mitigación: siempre mantener ≥ 2 super_admins por org (checklist operativo).

---

**Mantenedor:** Dueño del proyecto
**Última actualización:** 2026-04-22
