# CHANGELOG

> **Ruta:** `/CHANGELOG.md`

Todos los cambios notables de este proyecto se documentan aquí.
El formato se basa en [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/)
y este proyecto sigue [Semantic Versioning](https://semver.org/lang/es/).

---

## [Unreleased]

### Added
- Nada pendiente de release.

---

## [0.2.0] - 2026-04-22 — RBAC Enterprise

### Added

**Base de datos**
- Migración `20260422000001_rbac_schema.sql` con 7 tablas nuevas:
  `permissions`, `roles`, `role_permissions`, `user_roles`, `user_permissions`, `invitations`, `permission_audit_log`.
- Migración `20260422000002_rbac_seed.sql` con catálogo de 60+ permisos atómicos organizados en 13 categorías.
- Migración `20260422000002_rbac_seed.sql` con 5 roles del sistema preconfigurados: Super Admin, Admin, Supervisor, Agente, Viewer.
- Función `has_permission(user, key, scope, team, owner)` con resolución completa: deny explícito > super_admin > grants > roles > scopes.
- Función `get_user_permissions(user)` para carga inicial del cache de permisos.
- Función helper `current_user_has()` para usar en políticas RLS.
- Migración `20260422000003_rbac_functions.sql` que migra automáticamente los `users.role` existentes a registros en `user_roles`.
- Triggers automáticos de auditoría en `user_roles` y `user_permissions`.
- Políticas RLS completas para las 7 tablas nuevas.
- Migración `20260422000004_invitation_public_read.sql` con policy pública y vista filtrada para el flujo de aceptación de invitación sin autenticación previa.

**Edge Functions**
- `supabase/functions/user-invite/` — Envío de invitación por email con token criptográfico (integración Resend opcional).
- `supabase/functions/user-accept-invite/` — Aceptación de invitación: crea `auth.users`, `public.users`, `user_roles` y `agents` en una sola transacción lógica.
- `supabase/functions/user-create/` — Alta directa con contraseña temporal y flag `must_change_password` para forzar cambio al primer login.

**Frontend — Tipos y servicios**
- `src/types/rbac.types.ts` — Tipos: Permission, Role, UserRole, UserPermission, Invitation, PermissionAuditEntry, PermissionScope. Constante `KNOWN_PERMISSIONS` para autocompletado en IDE.
- `src/repository/supabase/rbac.repo.ts` — Repositorio completo: list/create/update/delete para roles, asignación de permisos, invitaciones, auditoría.
- `src/repository/supabase/user.repo.ts` — Gestión de miembros de la organización con sus roles incluidos.

**Frontend — Estado y lógica**
- `src/stores/permissions.store.ts` — Cache de permisos efectivos con lookup O(1). Métodos `can()`, `canAny()`, `canAll()`, `scopeOf()`, `isSuperAdmin`.
- `src/composables/useCan.ts` — API ergonómica para componentes. Incluye versión reactiva `useCanRef()`.
- `src/directives/can.ts` — Directiva global `v-can` con modificadores `.any`, `.all`, `.not`.

**Frontend — UI**
- `src/modules/agents/views/UsersView.vue` — Tabla de miembros con búsqueda, badges de roles, activar/desactivar, editar roles.
- `src/modules/agents/views/RolesView.vue` — Editor visual de roles con selección de permisos por categoría y scope (own/team/all).
- `src/modules/agents/views/InvitationsView.vue` — Listado de invitaciones con filtros por estado; copiar link y revocar.
- `src/modules/agents/views/AuditLogView.vue` — Timeline de eventos de auditoría con filtros, paginación y modal de detalle con before/after state.
- `src/modules/agents/components/InviteUserModal.vue` — Formulario de invitación con fallback de link copiable.
- `src/modules/agents/components/CreateUserModal.vue` — Alta directa con generador de contraseña y vista de credenciales.
- `src/modules/agents/components/EditUserRolesModal.vue` — Toggle de roles con feedback visual.
- `src/modules/auth/views/AcceptInviteView.vue` — Página pública de aterrizaje del link de invitación; valida token, crea cuenta y hace auto-login.
- `src/modules/auth/views/ChangePasswordView.vue` — Vista de cambio de contraseña forzado para usuarios con flag `must_change_password`.

**Documentación**
- `docs/RBAC_INTEGRATION.md` — Guía paso a paso de integración, testing y uso.

### Changed

- `src/main.ts` — Registra directiva global `v-can`.
- `src/stores/auth.store.ts` — Tras `loadProfile()` carga permisos efectivos vía `permissions.store.load()`. Agregados `updatePassword()`, `refreshPermissions()`, getter `mustChangePassword`. Limpia el store de permisos al signout.
- `src/repository/index.ts` — Exporta `rbac` y `users` en el factory de repositorios.
- `src/router/index.ts` — Nuevas rutas:
  - Públicas: `/auth/accept-invite`
  - Autenticadas: `/auth/change-password`, `/admin/users`, `/admin/roles`, `/admin/invitations`, `/admin/audit`
  - Meta de rutas cambiado de `roles: []` a `permission: '...'` (ambos compatibles por transición).
- `src/router/guards.ts` — Agregados `permissionGuard` (lee `meta.permission/permissionAny/permissionAll`) y `mustChangePasswordGuard` (redirige a `/auth/change-password` si aplica).
- `src/layouts/AdminLayout.vue` — Menú lateral agrupado por secciones y filtrado por permisos. Nueva sección "Administración".

### Deprecated

- `users.role` (columna) — Se mantiene por compatibilidad hacia atrás. La fuente de verdad ahora es `user_roles` + `roles` + `permissions`. Marcado con comentario SQL.
- `roleGuard` en `src/router/guards.ts` — Se mantiene para rutas que aún usen `meta.roles`, pero el guard recomendado es `permissionGuard`.

### Security

- Tokens de invitación generados con `gen_random_bytes(32)` — 256 bits de entropía.
- Auditoría automática con triggers de PostgreSQL: imposible de saltar desde el cliente.
- `user-accept-invite` desplegada con `--no-verify-jwt`; la seguridad la garantiza el token criptográfico único y su verificación contra la DB.
- Policy pública de `invitations` restringida a `SELECT` y protegida por token en la query.
- Permisos etiquetados como `is_dangerous` (delete, transfer de credenciales, billing) para resaltar en UI.

---

## [0.1.0] - 2026-04-21 — Setup Inicial

### Added
- `CONTEXT.md` con visión y principios arquitectónicos del proyecto.
- `CHANGELOG.md` siguiendo formato Keep a Changelog.
- `README.md` con guía de arranque local.
- Estructura completa de carpetas (`src/`, `supabase/`, `widget/`, `docs/`, `scripts/`).
- `.gitignore` con exclusiones estándar Vue + Supabase + entorno.
- `.env.example` con todas las variables de entorno documentadas (Supabase, Claude, Meta, Telegram, Twilio, Notion).
- `package.json` con dependencias base (Vue 3, Vite, Pinia, Vue Router, Tailwind, Supabase JS, Axios, Day.js, VueUse, Chart.js, vue-chartjs).
- `tsconfig.json` con modo estricto activado.
- `vite.config.ts` con alias `@` → `./src`.
- `tailwind.config.ts` con tokens de diseño iniciales.
- `postcss.config.js`.
- `src/main.ts` como punto de entrada.
- `src/App.vue` raíz.
- `src/router/index.ts` con rutas base.
- `src/router/guards.ts` con guard por rol.
- `src/stores/auth.store.ts` store de autenticación con Pinia.
- `src/repository/base.repository.ts` — interfaz genérica `IRepository<T>`.
- `src/repository/index.ts` — factory del repositorio activo.
- `src/repository/supabase/` — implementaciones iniciales (conversation, message, agent).
- `src/services/supabase.client.ts` — cliente único de Supabase.
- `src/services/claude.service.ts` — cliente Claude API (stub).
- `src/types/` — tipos TypeScript base (conversation, message, agent, user, channel).
- `src/layouts/AdminLayout.vue` y `src/layouts/AuthLayout.vue`.
- `supabase/migrations/20260421000001_init_schema.sql` — schema completo inicial con 14 tablas.
- `supabase/migrations/20260421000002_rls_policies.sql` — políticas RLS para todas las tablas.
- `supabase/migrations/20260421000003_functions_triggers.sql` — funciones y triggers (updated_at, auto-asignación, métricas).
- `supabase/seed/seed.sql` — datos iniciales de prueba.
- `supabase/functions/meta-webhook/index.ts` — esqueleto del webhook de Meta.
- `.github/workflows/deploy-staging.yml` — pipeline de staging.
- `.github/workflows/deploy-prod.yml` — pipeline de producción.
- `.github/pull_request_template.md`.
- `docs/ARCHITECTURE.md` — diagrama y explicación de capas.
- `docs/GIT_WORKFLOW.md` — guía del flujo Git del proyecto.
- `docs/DATABASE.md` — documentación del schema.

### Security
- RLS activado por defecto en todas las tablas del schema inicial.
- Variables sensibles (`ANTHROPIC_API_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, tokens Meta) separadas de variables `VITE_*`.
- `.env*` excluidos de Git vía `.gitignore`.

---

## Formato de Versionado

- **MAJOR** (1.0.0 → 2.0.0): Cambios incompatibles de API.
- **MINOR** (0.1.0 → 0.2.0): Nueva funcionalidad compatible hacia atrás.
- **PATCH** (0.1.0 → 0.1.1): Correcciones compatibles hacia atrás.

## Tipos de Cambios

- `Added` — nuevas funcionalidades.
- `Changed` — cambios en funcionalidades existentes.
- `Deprecated` — funcionalidades que serán removidas.
- `Removed` — funcionalidades removidas.
- `Fixed` — corrección de bugs.
- `Security` — vulnerabilidades y cambios de seguridad.
