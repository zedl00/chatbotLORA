# Sprint 7 — Rebranding LORA · Guía de aplicación

Contiene 8 archivos (6 nuevos/modificados + 2 configuración) para completar el rebranding oficial de "ChatBot IA" → "LORA".

## 📂 Archivos incluidos

```
lora-rebrand/
├── README.md                                     ← este archivo
├── public/
│   └── favicon.svg                               ← NUEVO favicon animado
├── index.html                                    ← MODIFICADO (reemplaza el raíz)
├── package.json                                  ← MODIFICADO (reemplaza el raíz)
└── src/
    ├── components/
    │   └── LoraLogo.vue                          ← NUEVO componente reutilizable
    ├── composables/
    │   └── useDocumentTitle.ts                   ← NUEVO (title dinámico)
    ├── layouts/
    │   ├── AdminLayout.vue                       ← MODIFICADO (sidebar con LoraLogo)
    │   └── AuthLayout.vue                        ← MODIFICADO (mesh + branding)
    └── modules/
        └── auth/
            └── views/
                └── LoginView.vue                 ← MODIFICADO (logo animado + copy)
```

## 🚀 Instalación (5 pasos)

### 1. Backup

```powershell
cd C:\xampp\htdocs\proyectos\chatbot

# Crea una rama de git por si acaso
git checkout -b feat/sprint-7-rebranding
git add -A && git commit -m "pre-rebranding snapshot"
```

### 2. Copiar archivos del ZIP a tu proyecto

Descomprime el ZIP y copia cada archivo a la misma ruta en tu proyecto:

| Archivo del ZIP | Destino en tu proyecto |
|---|---|
| `public/favicon.svg` | `public/favicon.svg` (reemplaza el actual) |
| `index.html` | `index.html` (raíz, reemplaza el actual) |
| `package.json` | `package.json` (raíz, solo cambia `description` y `version`) |
| `src/components/LoraLogo.vue` | `src/components/LoraLogo.vue` (crea la carpeta si no existe) |
| `src/composables/useDocumentTitle.ts` | `src/composables/useDocumentTitle.ts` |
| `src/layouts/AdminLayout.vue` | `src/layouts/AdminLayout.vue` (reemplaza el actual) |
| `src/layouts/AuthLayout.vue` | `src/layouts/AuthLayout.vue` (reemplaza el actual) |
| `src/modules/auth/views/LoginView.vue` | `src/modules/auth/views/LoginView.vue` (reemplaza) |

### 3. Verificar rutas en router (meta.title)

En `src/router/index.ts` asegúrate que las rutas tengan `meta.title`. Ejemplo:

```typescript
{ path: 'inbox', name: 'admin.inbox', component: ..., meta: { permission: 'conversations.read', title: 'Bandeja' } }
```

Si ya las tienes (las vi en tu archivo), no hay que tocar nada. Si no, agrégales `title` para que el título de la pestaña funcione.

### 4. Build y prueba local

```powershell
npm run build
npm run dev
```

Abre `http://localhost:5173` y valida el checklist abajo.

### 5. Deploy a producción

```powershell
# Build (si no lo hiciste antes)
npm run build

# Subir contenido de /dist/ vía FTP a /public_html/ de admin.lorachat.net
```

## ✅ Checklist de validación

Después del deploy:

- [ ] La pestaña del navegador muestra **"LORA · {vista}"** (ej: "LORA · Bandeja")
- [ ] El favicon es el wordmark azul con gradient animado (cycle 6s)
- [ ] El sidebar del admin muestra el wordmark **LORA.** (con punto que pulsa)
- [ ] Click sobre el wordmark del sidebar → el punto escala levemente
- [ ] Login → ves el panel izquierdo con gradient azul + logo LORA grande animado
- [ ] Copy de login dice **"Bienvenido."** en lugar de "Iniciar sesión"
- [ ] Botón de login tiene spinner cuando está cargando
- [ ] Mobile → el logo pequeño aparece arriba del formulario
- [ ] No hay strings de "ChatBot IA" visibles en ninguna vista del admin

## 🔁 Rollback

Si algo falla después de aplicar el rebranding:

```powershell
git checkout main
git branch -D feat/sprint-7-rebranding
```

Vuelves al estado previo al rebranding en segundos.

## 📝 Archivos NO incluidos pero recomendados cambiar manualmente

Estos archivos tienen menciones de "ChatBot IA" que no afectan al UI pero conviene limpiar eventualmente:

- `public/widget.js` línea 3 y 502: "CHATBOT IA" y "Powered by ChatBot IA"
- `widget/src/widget.js` líneas 3 y 490: mismas referencias
- `src/services/supabase.client.ts` líneas 20 y 26: `chatbot-ia-auth` y `x-application-name`
- `src/modules/channels/components/WidgetInstallSnippet.vue` línea 19: comentario del snippet
- `src/modules/channels/components/WidgetConfigEditor.vue` línea 104: "Powered by ChatBot IA"
- `docs/*.md` y `README.md`: documentación interna

**Recomendación:** los archivos de `src/modules/channels/` (WidgetInstallSnippet y WidgetConfigEditor) sí afectan al UI que ven los admins cuando van a "Canales". Te sugiero que me los pases en otra sesión para actualizarlos también.

## 🎨 Paleta usada

```
--blue-600 (primary):  #0071E3   ← Apple blue exacto
--cyan:                #06B6D4   ← acento
--violet:              #8B5CF6   ← acento

Gradient signature: linear-gradient(135deg, #0071E3 → #06B6D4 → #8B5CF6)
```

---

© 2026 Jab Enterprises · LORA Chat v0.2.0
