<!-- Ruta: /src/modules/auth/views/LoginView.vue -->
<!-- ═══════════════════════════════════════════════════════════════
     MODIFICADO en Sprint 7 (Rebranding LORA):
       - Logo animado arriba del formulario (solo visible en desktop).
       - Copy más cálido: "Bienvenido a LORA" vs "Iniciar sesión".
       - Botón con loading más premium (spinner inline).
     ═══════════════════════════════════════════════════════════════ -->
<script setup lang="ts">
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth.store'

const authStore = useAuthStore()
const router = useRouter()
const route = useRoute()

const email = ref('')
const password = ref('')
const error = ref<string | null>(null)
const loading = ref(false)

async function handleSubmit() {
  error.value = null
  loading.value = true
  try {
    await authStore.signIn(email.value, password.value)
    const redirect = (route.query.redirect as string) || '/admin/dashboard'
    router.push(redirect)
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Error al iniciar sesión'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="space-y-7">
    <!-- Header con bienvenida -->
    <div>
      <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Bienvenido.</h2>
      <p class="text-slate-500 mt-1.5 text-sm">
        Accede a tu panel de LORA para continuar.
      </p>
    </div>

    <form class="space-y-4" @submit.prevent="handleSubmit">
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1.5">Email</label>
        <input
          v-model="email"
          type="email"
          required
          class="input"
          placeholder="tucorreo@empresa.com"
          autocomplete="email"
        />
      </div>

      <div>
        <div class="flex items-center justify-between mb-1.5">
          <label class="block text-sm font-medium text-slate-700">Contraseña</label>
          <RouterLink
            to="/auth/forgot-password"
            class="text-xs text-brand-600 hover:underline"
          >
            ¿Olvidaste tu contraseña?
          </RouterLink>
        </div>
        <input
          v-model="password"
          type="password"
          required
          class="input"
          placeholder="••••••••"
          autocomplete="current-password"
        />
      </div>

      <!-- Error message con estilo refinado -->
      <transition name="error">
        <div
          v-if="error"
          class="flex items-start gap-2 text-sm text-red-700 bg-red-50 border border-red-100 px-3 py-2.5 rounded-lg"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
               stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
               class="flex-shrink-0 mt-0.5">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="12"/>
            <line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          <span>{{ error }}</span>
        </div>
      </transition>

      <!-- Botón con loading state premium -->
      <button
        type="submit"
        class="btn-primary w-full relative overflow-hidden"
        :disabled="loading"
      >
        <span class="flex items-center justify-center gap-2">
          <svg
            v-if="loading"
            class="animate-spin"
            width="16" height="16"
            viewBox="0 0 24 24"
            fill="none"
          >
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25" stroke-width="3"/>
            <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
          </svg>
          {{ loading ? 'Ingresando…' : 'Ingresar' }}
        </span>
      </button>
    </form>

    <!-- Separador sutil + info adicional -->
    <div class="pt-4 border-t border-slate-100">
      <p class="text-xs text-slate-400 text-center">
        Protegido por Supabase Auth · Cifrado end-to-end
      </p>
    </div>
  </div>
</template>

<style scoped>
.error-enter-active, .error-leave-active {
  transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}
.error-enter-from, .error-leave-to {
  opacity: 0;
  transform: translateY(-6px);
}

button[disabled] {
  opacity: 0.7;
  cursor: not-allowed;
}
</style>
