// Ruta: /src/composables/useActiveOrganizationId.ts
// ═══════════════════════════════════════════════════════════════
// Sprint 6.5 (fix): Composable para obtener el ID de organización
// "efectivo" para filtrar queries en un contexto multi-tenant.
//
// Reglas:
//   1. Si el usuario es super_admin Y está operando en un tenant
//      ajeno (modo soporte) → devuelve el ID del tenant activo.
//   2. Si no → devuelve el ID de la organización del usuario.
//
// Ejemplo:
//   - Super_admin en admin.lorachat.net → devuelve su orgId (Jab)
//   - Super_admin en capitali.lorachat.net → devuelve orgId de Capitali
//   - CapitaliRD en capitali.lorachat.net → devuelve orgId de Capitali
//   - CapitaliRD en jab.lorachat.net → no llega aquí, el guard lo bloquea
//
// USO:
//   const activeOrgId = useActiveOrganizationId()
//   // En una función:
//   const orgId = activeOrgId.value
//   if (!orgId) return
//   const { data } = await supabase.from('conversations')
//     .select('*').eq('organization_id', orgId)
// ═══════════════════════════════════════════════════════════════
import { computed, type ComputedRef } from 'vue'
import { useAuthStore } from '@/stores/auth.store'
import { useOrganizationStore } from '@/stores/organization.store'

/**
 * Devuelve un computed con el ID de la organización que debe usarse
 * para filtrar queries en el contexto actual.
 *
 * Retorna null si no hay contexto válido.
 */
export function useActiveOrganizationId(): ComputedRef<string | null> {
  const auth = useAuthStore()
  const orgStore = useOrganizationStore()

  return computed(() => {
    if (!auth.user) return null

    const isSuperAdmin = auth.user.role === 'super_admin'
    const isInTenantContext = orgStore.isTenant && orgStore.current !== null

    // Caso 1: super_admin operando en un tenant ajeno (modo soporte)
    if (isSuperAdmin && isInTenantContext && orgStore.current) {
      return orgStore.current.id
    }

    // Caso 2: usuario normal → su propia org
    return auth.user.organizationId
  })
}

/**
 * Versión helper síncrona: obtiene el ID sin reactividad.
 * Útil cuando se necesita llamar desde funciones que no corren dentro
 * del setup() de un componente (por ejemplo, repositories o servicios).
 *
 * Devuelve null si no hay contexto válido.
 */
export function getActiveOrganizationId(): string | null {
  const auth = useAuthStore()
  const orgStore = useOrganizationStore()

  if (!auth.user) return null

  const isSuperAdmin = auth.user.role === 'super_admin'
  const isInTenantContext = orgStore.isTenant && orgStore.current !== null

  if (isSuperAdmin && isInTenantContext && orgStore.current) {
    return orgStore.current.id
  }

  return auth.user.organizationId
}
