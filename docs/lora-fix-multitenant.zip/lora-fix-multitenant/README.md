# 🔧 Sprint 6.5 — Fix aislamiento multi-tenant

Fix urgente del bug de seguridad donde super_admin en modo soporte
veía datos de su propia org en lugar del tenant activo.

## 📋 Archivos (parte 1 — ya incluidos)

| Archivo | Estado |
|---|---|
| `src/composables/useActiveOrganizationId.ts` | 🆕 Nuevo |
| `src/modules/inbox/views/InboxView.vue` | 🔧 Reemplazar |

## 📋 Archivos PENDIENTES (te los paso cuando subas los archivos que faltan)

Para hacer el fix completo necesito que me subas:

1. `src/repository/supabase/inbox.repo.ts` — el repo real del Inbox
2. `src/modules/contacts/views/ContactsView.vue` — si tiene el mismo bug
3. `src/modules/reports/views/DashboardView.vue` — idem
4. Cualquier otro View/store que filtre por org

## 🎯 Cómo probar (con estos 2 archivos)

### Test 1: super_admin en modo soporte
1. `VITE_DEV_SUBDOMAIN=capitali` en `.env.local`
2. Reiniciar `npm run dev`
3. Login como super_admin
4. Ir a Inbox
5. **Esperado:** Inbox VACÍO (Capitali no tiene conversaciones)
6. NO debe mostrar las 17 de Jab ✓

### Test 2: super_admin en su propio panel
1. `VITE_DEV_SUBDOMAIN=` (vacío)
2. Reiniciar
3. Login
4. Ir a Inbox
5. **Esperado:** ver las 17 conversaciones de Jab ✓

## 🔍 Qué cambia

Antes:
```ts
if (!auth.organizationId) return
await repo.listConversations(auth.organizationId, ...)
```

Ahora:
```ts
if (!activeOrgId.value) return
await repo.listConversations(activeOrgId.value, ...)
```

El composable `useActiveOrganizationId()` resuelve:
- Super_admin + modo soporte → usa `orgStore.current.id`
- Caso normal → usa `auth.user.organizationId`
