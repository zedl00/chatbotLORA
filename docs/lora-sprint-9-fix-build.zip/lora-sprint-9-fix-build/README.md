# 🔧 Fix Build Sprint 9 — 2 errores TypeScript

## 🐛 Errores que viste

### Error 1
```
ConversationThread.vue:367 - TS2367: This comparison appears to be unintentional 
because the types '"agent" | "contact" | "bot"' and '"whisper"' have no overlap.
```

**Causa:** el tipo `InboxMessage.senderType` en tu `inbox.types.ts` aún lista
solo `'agent' | 'contact' | 'bot'`. Falta agregar `'whisper'` y `'system'`.

TypeScript del frontend **no se entera** automáticamente de que el enum de
Postgres ahora acepta más valores. Hay que declararlo manualmente.

### Error 2
```
escalations.store.ts:68 - TS6133: 'row' is declared but its value is never read.
```

**Causa:** TypeScript estricto con `noUnusedParameters` rechaza parámetros sin
usar. Mi callback recibía `row` pero no lo usa (recargo la lista completa).

---

## ✅ Fix 1: escalations.store.ts

Ya está en este ZIP en `src/stores/escalations.store.ts`. Solo cambia **1 línea**:

**Antes:**
```ts
unsubscribe = repo.subscribeToEscalations(organizationId, async (row) => {
```

**Ahora:**
```ts
unsubscribe = repo.subscribeToEscalations(organizationId, async (_row) => {
```

El prefijo `_` le dice a TS: "sé que no lo uso, es intencional".

## ✅ Fix 2: Tipo senderType

No puedo entregarte un archivo ya hecho porque **no sé la estructura exacta**
de tu `inbox.types.ts`. Pero el fix es **mínimo** (1 línea).

### Paso 1: Encuentra el archivo

Abre: `src/types/inbox.types.ts`

### Paso 2: Busca la definición de `InboxMessage` o el tipo de `senderType`

Debería verse más o menos así:

```ts
export interface InboxMessage {
  id: string
  conversationId: string
  senderType: 'agent' | 'contact' | 'bot'   // ← ESTA LÍNEA
  // ...
}
```

O tal vez como un tipo alias:

```ts
export type SenderType = 'agent' | 'contact' | 'bot'
```

### Paso 3: Agrega 'whisper' y 'system'

**Antes:**
```ts
senderType: 'agent' | 'contact' | 'bot'
```

**Ahora:**
```ts
senderType: 'agent' | 'contact' | 'bot' | 'whisper' | 'system'
```

O si es un type alias:

**Antes:**
```ts
export type SenderType = 'agent' | 'contact' | 'bot'
```

**Ahora:**
```ts
export type SenderType = 'agent' | 'contact' | 'bot' | 'whisper' | 'system'
```

### Paso 4: Rebuild

```powershell
npm run build
```

Debe pasar ✅

---

## 💡 Si tienes problemas para encontrar el tipo

**Opción A:** Ctrl+Shift+F en VS Code → buscar: `senderType:`
Aparecerán todas las definiciones. Busca la que está en `src/types/...`

**Opción B:** Súbeme el archivo `src/types/inbox.types.ts` y te lo entrego ya modificado.

---

## 🎯 Por qué pasó esto

El sistema de tipos de TypeScript es **independiente** del enum de Postgres:

- **Postgres:** enum `sender_type` con 5 valores (contact, agent, bot, whisper, system)
- **TypeScript:** unión literal con 3 valores (agent, contact, bot)

Hay que **sincronizarlos manualmente**. Lo ideal es tener un **archivo de tipos
centralizado** que coincida exactamente con el enum de la DB.

En sprints futuros, si agregamos valores al enum, también hay que actualizar
el tipo TS. Un buen hábito: cada `ALTER TYPE ... ADD VALUE` va acompañado de
su actualización en `types/inbox.types.ts`.

---

## 📦 Archivos en este ZIP

- `src/stores/escalations.store.ts` — fix del parámetro `_row`

## 📝 Lo que haces tú

Editar manualmente `src/types/inbox.types.ts` agregando `'whisper' | 'system'` al
tipo `senderType` o `SenderType`.

---

## Después del fix

1. `npm run build` → debe pasar
2. `npm run dev` → smoke tests
3. Deploy FTP
4. Tests en producción
