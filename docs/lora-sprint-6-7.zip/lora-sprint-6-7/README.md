# 🚀 Sprint 6 + 7 — Modo soporte + Editor de branding

Este paquete agrega 2 funcionalidades a LORA:

- **Sprint 6:** Modo soporte super_admin (banner + logs + confirmaciones)
- **Sprint 7:** Editor de branding per-tenant (color, logo, mensajes del widget)

---

## 📋 Archivos incluidos

Todos con rutas completas desde `/src` (listos para copiar y pegar):

| Ruta | Estado | Sprint |
|---|---|---|
| `supabase/migrations/20260423_sprint6_7_storage_support.sql` | 🆕 Nuevo | 6+7 |
| `src/composables/useSupportMode.ts` | 🆕 Nuevo | 6 |
| `src/composables/useLogoUpload.ts` | 🆕 Nuevo | 7 |
| `src/components/SupportModeBanner.vue` | 🆕 Nuevo | 6 |
| `src/layouts/AdminLayout.vue` | 🔧 Reemplazar | 6 |
| `src/modules/settings/components/LogoUploader.vue` | 🆕 Nuevo | 7 |
| `src/modules/settings/views/BrandingView.vue` | 🆕 Nuevo | 7 |
| `src/router/index.ts` | 🔧 Reemplazar | 7 |

---

## 🔧 Instalación paso a paso

### Paso 1: Aplicar migración SQL

1. Abre Supabase Dashboard → SQL Editor
2. Copia el contenido de `supabase/migrations/20260423_sprint6_7_storage_support.sql`
3. Ejecuta
4. Al final verás la verificación:
   ```
   status='Sprint 6+7 migración aplicada'
   buckets_creados=1
   policies_storage=4
   funciones=1
   ```

### Paso 2: Copiar archivos al proyecto

Cada archivo viene con su ruta completa. Simplemente replica la estructura en tu proyecto:

```
Desde el ZIP:                        →   A tu proyecto:
src/composables/useSupportMode.ts    →   C:\xampp\htdocs\proyectos\chatbot\src\composables\useSupportMode.ts
src/composables/useLogoUpload.ts     →   C:\xampp\htdocs\proyectos\chatbot\src\composables\useLogoUpload.ts
src/components/SupportModeBanner.vue →   C:\xampp\htdocs\proyectos\chatbot\src\components\SupportModeBanner.vue
src/layouts/AdminLayout.vue          →   C:\xampp\htdocs\proyectos\chatbot\src\layouts\AdminLayout.vue (REEMPLAZAR)
src/modules/settings/components/LogoUploader.vue → C:\xampp\htdocs\proyectos\chatbot\src\modules\settings\components\LogoUploader.vue
src/modules/settings/views/BrandingView.vue      → C:\xampp\htdocs\proyectos\chatbot\src\modules\settings\views\BrandingView.vue
src/router/index.ts                  →   C:\xampp\htdocs\proyectos\chatbot\src\router\index.ts (REEMPLAZAR)
```

### Paso 3: Probar localmente

```powershell
npm run dev
```

#### Test 1 — Modo soporte (Sprint 6)
1. Edita `.env.local` y pon `VITE_DEV_SUBDOMAIN=capitali` (o cualquier empresa que NO sea tu Jab)
2. Reinicia `npm run dev`
3. Login como super_admin (`nestorvaldez@hotmail.com`)
4. **Deberías ver banner naranja arriba del panel:** "Modo soporte activo · Estás viendo los datos de Capitali..."
5. Click en "← Volver a mi panel" → redirect a admin.lorachat.net

#### Test 2 — Login normal NO muestra banner
1. Logout
2. Edita `.env.local`: `VITE_DEV_SUBDOMAIN=jab` (o vacío)
3. Login como super_admin
4. **NO debe aparecer banner** (estás en tu propio panel)

#### Test 3 — Editor de branding (Sprint 7)
1. Con `VITE_DEV_SUBDOMAIN=capitali`
2. Login como `capitalird@gmail.com` (admin de Capitali)
3. Ve al sidebar → sección **Configuración** → **"Branding"** 🎨
4. Prueba:
   - Subir un logo (drag & drop funciona, o click para seleccionar)
   - Cambiar el color primario → ver preview del widget actualizarse en vivo
   - Cambiar tab a "Mensajes del widget" → editar títulos
5. Click en **"Guardar cambios"** → toast de éxito
6. Recarga la página → los cambios persisten ✓
7. El sidebar muestra el logo nuevo

### Paso 4: Build de producción

```powershell
npm run build
```

Si sale algún error de TypeScript, pégamelo y lo resolvemos.

### Paso 5: Deploy via FTP

1. Sube contenido de `dist/` a `/public_html/admin.lorachat.net/`
2. Prueba en incógnita:
   - `admin.lorachat.net` como super_admin → sin banner
   - `capitali.lorachat.net` como super_admin → CON banner
   - `capitali.lorachat.net` como capitalird → ver menú Branding en sidebar

---

## 🎯 Lo que logras con este paquete

### Sprint 6 — Modo soporte

✅ Banner naranja visible cuando super_admin entra a tenant ajeno
✅ Botón rápido "Volver a mi panel"
✅ Logs de auditoría con prefix `support_mode.*`
✅ Función SQL `log_support_mode_action` lista para usar en otros módulos
✅ Helper `confirmIfSupportMode()` para acciones destructivas

### Sprint 7 — Editor de branding

✅ Upload de logo con drag & drop (PNG/JPG/WEBP/SVG, máx 2MB)
✅ Color picker con preview del widget en vivo
✅ Editor de mensajes del widget (bienvenida, subtítulo, offline)
✅ Preview lateral igualito al que verá el usuario final
✅ Permisos: solo roles con `settings.update` (admin y super_admin)
✅ Super_admin puede editar branding de cualquier empresa (en modo soporte)
✅ Storage con RLS: cada empresa solo puede subir a su propia carpeta

---

## 🗂️ Storage en Supabase

Después de aplicar la migración, en Supabase → Storage verás:

```
📁 organization-logos (bucket público)
   📁 {org_id_1}/
      └── logo-1234567890.png
   📁 {org_id_2}/
      └── logo-9876543210.jpg
```

Las policies aseguran:
- Cualquiera puede **leer** (necesario para el widget público)
- Solo admins de la org pueden **subir/borrar** en su carpeta
- Super_admin puede gestionar cualquier carpeta

---

## 🧪 Queries útiles para debugging

### Ver logs de super_admin en modo soporte
```sql
SELECT
  al.created_at,
  al.action,
  u.email AS super_admin,
  o.name AS target_org,
  al.changes
FROM audit_logs al
JOIN users u ON u.id = al.user_id
JOIN organizations o ON o.id = al.organization_id
WHERE action LIKE 'support_mode.%'
ORDER BY al.created_at DESC
LIMIT 10;
```

### Ver logos subidos
```sql
SELECT
  name,
  created_at,
  ROUND((metadata->>'size')::numeric / 1024, 1) AS kb
FROM storage.objects
WHERE bucket_id = 'organization-logos'
ORDER BY created_at DESC;
```

### Ver qué roles tienen permiso settings.update (para saber quién puede editar branding)
```sql
SELECT DISTINCT
  r.key AS role_key,
  r.name AS role_name,
  o.name AS org
FROM role_permissions rp
JOIN permissions p ON p.id = rp.permission_id
JOIN roles r ON r.id = rp.role_id
JOIN organizations o ON o.id = r.organization_id
WHERE p.key = 'settings.update'
ORDER BY o.name, r.key;
```

---

## ❓ Troubleshooting

### "new row violates row-level security policy" al subir logo
La policy de upload falló. Verifica:
- Estás logueado
- Tu user tiene `role='admin'` o `role='super_admin'` en la tabla `users`
- Tienes el permiso `settings.update` (si no eres super_admin)

### El banner de modo soporte no aparece en producción
Verifica:
- Tu `user.role` es `'super_admin'`
- Estás en un subdomain que NO es tu empresa (ej: entraste a `capitali.lorachat.net` pero tu org_id es el de Jab)
- Si estás en `admin.lorachat.net` directo, no estás en modo soporte (estás en tu panel)

### El logo no se ve en el sidebar después de subirlo
Recarga la página (F5). El store se actualiza pero el render puede necesitar reload.

### Error de TypeScript en build: "Cannot find module '@/modules/settings/views/BrandingView.vue'"
El archivo no se copió al directorio correcto. Verifica que existe en:
`src/modules/settings/views/BrandingView.vue`

### Error: "Property 'settings.update' does not exist"
La ruta `/admin/branding` requiere el permiso `settings.update`. Si tu admin no lo tiene, se redirige al dashboard. Solución: asigna el permiso al rol admin desde `/admin/roles`.

---

## 🎯 Próximos sprints sugeridos

Después de deployar este paquete, los siguientes pasos recomendados:

**Sprint 8 — Email automático de invitaciones (2h)**
Elimina el copy-paste manual de links. Integra Resend o Brevo para que las empresas nuevas reciban invitaciones por email.

**Sprint 9 — Telegram como 2do canal (2-3h)**
Primer canal adicional al widget web. Abre mercado a clientes que quieren Telegram-first.

**Sprint 11 — Facturación Stripe (6h)**
Monetización: 3 planes (Starter $29 / Pro $99 / Business $249) con gates por features.

---

## 📝 Commit sugerido

Cuando todo funcione, haz un solo commit:

```bash
git add -A
git commit -m "feat(sprint-6-7): modo soporte + editor de branding per-tenant

Sprint 6 - Modo soporte super_admin:
- Banner naranja cuando super_admin opera en tenant ajeno
- Composable useSupportMode con logs de auditoria
- Funcion SQL log_support_mode_action para otros modulos
- Confirmaciones extra en acciones destructivas

Sprint 7 - Editor de branding:
- Nueva ruta /admin/branding con permission settings.update
- Upload de logo con drag-drop (bucket organization-logos)
- Storage policies: cada org solo accede a su carpeta
- Editor de color, brand_name, mensajes del widget
- Preview del widget en vivo al lado del formulario
- super_admin puede editar branding en modo soporte

Migracion SQL:
- Bucket organization-logos con policies RLS
- Funcion log_support_mode_action"

git push origin main
```

¡Listo para seguir después del deploy! 🚀
