// Ruta: /src/repository/index.ts
// ═══════════════════════════════════════════════════════════════
// FACTORY DEL REPOSITORIO
// Punto único de acceso a la capa de datos para toda la app.
//
// 🔑 IMPORTANTE: Para cambiar de Supabase a otra base de datos:
//   1. Crear carpeta /src/repository/<nuevo-proveedor>/
//   2. Implementar cada *.repo.ts cumpliendo la interfaz IRepository
//   3. Cambiar los imports de abajo por la nueva implementación
// El resto de la app NO cambia.
// ═══════════════════════════════════════════════════════════════
import { SupabaseConversationRepo } from './supabase/conversation.repo'
import { SupabaseMessageRepo } from './supabase/message.repo'
import { SupabaseAgentRepo } from './supabase/agent.repo'
import { SupabaseContactRepo } from './supabase/contact.repo'
import { SupabaseChannelRepo } from './supabase/channel.repo'

// Provider activo — único lugar donde se elige la implementación.
const PROVIDER: 'supabase' = 'supabase'

export const repositories = {
  conversations: new SupabaseConversationRepo(),
  messages: new SupabaseMessageRepo(),
  agents: new SupabaseAgentRepo(),
  contacts: new SupabaseContactRepo(),
  channels: new SupabaseChannelRepo()
} as const

export type Repositories = typeof repositories

export function getActiveProvider(): string {
  return PROVIDER
}
