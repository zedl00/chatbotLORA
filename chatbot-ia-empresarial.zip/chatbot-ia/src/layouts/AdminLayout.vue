<!-- Ruta: /src/layouts/AdminLayout.vue -->
<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink, RouterView, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth.store'
import { useUiStore } from '@/stores/ui.store'
import { isRoleAtLeast, type UserRole } from '@/types/user.types'

const authStore = useAuthStore()
const uiStore = useUiStore()
const router = useRouter()

interface NavItem {
  to: string
  label: string
  icon: string
  minRole: UserRole
}

const navItems: NavItem[] = [
  { to: '/admin/dashboard', label: 'Dashboard',      icon: '📊', minRole: 'supervisor' },
  { to: '/admin/inbox',     label: 'Bandeja',        icon: '💬', minRole: 'agent' },
  { to: '/admin/my-inbox',  label: 'Mi bandeja',     icon: '📥', minRole: 'agent' },
  { to: '/admin/contacts',  label: 'Contactos',      icon: '👥', minRole: 'agent' },
  { to: '/admin/flows',     label: 'Flujos',         icon: '🔀', minRole: 'admin' },
  { to: '/admin/knowledge', label: 'Conocimiento',   icon: '📚', minRole: 'admin' },
  { to: '/admin/channels',  label: 'Canales',        icon: '🔌', minRole: 'admin' },
  { to: '/admin/agents',    label: 'Equipo',         icon: '🧑‍💼', minRole: 'admin' },
  { to: '/admin/reports',   label: 'Reportes',       icon: '📈', minRole: 'supervisor' },
  { to: '/admin/settings',  label: 'Configuración',  icon: '⚙️', minRole: 'admin' }
]

const visibleNav = computed(() => {
  const role = authStore.role
  if (!role) return []
  return navItems.filter((item) => isRoleAtLeast(role, item.minRole))
})

async function handleSignOut() {
  await authStore.signOut()
  router.push({ name: 'auth.login' })
}
</script>

<template>
  <div class="min-h-screen flex bg-surface-muted">
    <!-- Sidebar -->
    <aside
      class="bg-white border-r border-surface-border transition-all flex flex-col"
      :class="uiStore.sidebarCollapsed ? 'w-16' : 'w-64'"
    >
      <div class="h-16 flex items-center px-4 border-b border-surface-border">
        <div class="w-8 h-8 rounded-lg bg-brand-600 text-white grid place-items-center font-bold">
          C
        </div>
        <span v-if="!uiStore.sidebarCollapsed" class="ml-3 font-semibold">ChatBot IA</span>
      </div>

      <nav class="flex-1 p-2 space-y-1">
        <RouterLink
          v-for="item in visibleNav"
          :key="item.to"
          :to="item.to"
          class="flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-slate-700 hover:bg-surface-muted transition-colors"
          active-class="bg-brand-50 text-brand-700 font-medium"
        >
          <span class="text-lg">{{ item.icon }}</span>
          <span v-if="!uiStore.sidebarCollapsed">{{ item.label }}</span>
        </RouterLink>
      </nav>

      <div class="p-2 border-t border-surface-border">
        <button
          class="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-slate-700 hover:bg-surface-muted"
          @click="uiStore.toggleSidebar"
        >
          <span class="text-lg">{{ uiStore.sidebarCollapsed ? '▶' : '◀' }}</span>
          <span v-if="!uiStore.sidebarCollapsed">Colapsar</span>
        </button>
      </div>
    </aside>

    <!-- Main -->
    <div class="flex-1 flex flex-col min-w-0">
      <header class="h-16 bg-white border-b border-surface-border px-6 flex items-center justify-between">
        <h1 class="text-lg font-semibold text-slate-800">{{ $route.meta.title ?? '' }}</h1>

        <div class="flex items-center gap-4">
          <div class="text-right text-sm">
            <div class="font-medium">{{ authStore.user?.fullName ?? authStore.user?.email }}</div>
            <div class="text-slate-500 capitalize">{{ authStore.role?.replace('_', ' ') }}</div>
          </div>
          <button class="btn-secondary" @click="handleSignOut">Salir</button>
        </div>
      </header>

      <main class="flex-1 overflow-auto">
        <RouterView />
      </main>
    </div>

    <!-- Toasts -->
    <div class="fixed top-4 right-4 space-y-2 z-50">
      <div
        v-for="t in uiStore.toasts"
        :key="t.id"
        class="card px-4 py-3 min-w-[240px] text-sm"
        :class="{
          'border-l-4 border-l-emerald-500': t.type === 'success',
          'border-l-4 border-l-red-500': t.type === 'error',
          'border-l-4 border-l-amber-500': t.type === 'warning',
          'border-l-4 border-l-brand-500': t.type === 'info'
        }"
      >
        {{ t.message }}
      </div>
    </div>
  </div>
</template>
