// Ruta: /src/services/claude.service.ts
// Cliente frontend para invocar Edge Functions que a su vez llaman a Claude API.
// La clave ANTHROPIC_API_KEY NUNCA vive en el frontend.
import { supabase } from './supabase.client'

export interface ClaudeMessage {
  role: 'user' | 'assistant'
  content: string
}

export interface ClaudeChatParams {
  conversationId: string
  systemPrompt?: string
  messages: ClaudeMessage[]
  model?: 'claude-sonnet-4-20250514' | 'claude-haiku-4-5-20251001'
  maxTokens?: number
  useRag?: boolean
}

export interface ClaudeChatResult {
  content: string
  tokensUsed: number
  model: string
  handoffRequested: boolean
}

/**
 * Invoca la Edge Function 'claude-chat' que ejecuta la llamada a Anthropic API.
 * El backend se encarga del system prompt dinámico, RAG y registro de tokens.
 */
export async function callClaudeChat(params: ClaudeChatParams): Promise<ClaudeChatResult> {
  const { data, error } = await supabase.functions.invoke<ClaudeChatResult>('claude-chat', {
    body: params
  })

  if (error) {
    throw new Error(`[claude.service] Error al invocar claude-chat: ${error.message}`)
  }
  if (!data) {
    throw new Error('[claude.service] Respuesta vacía de claude-chat')
  }
  return data
}

/**
 * Sugerir respuesta al agente humano basado en el contexto de la conversación.
 */
export async function suggestReply(conversationId: string): Promise<string> {
  const { data, error } = await supabase.functions.invoke<{ suggestion: string }>('claude-suggest', {
    body: { conversationId }
  })

  if (error) throw new Error(`[claude.service] suggest: ${error.message}`)
  return data?.suggestion ?? ''
}

/**
 * Generar resumen de conversación para handoff.
 */
export async function summarizeConversation(conversationId: string): Promise<string> {
  const { data, error } = await supabase.functions.invoke<{ summary: string }>('claude-summarize', {
    body: { conversationId }
  })

  if (error) throw new Error(`[claude.service] summarize: ${error.message}`)
  return data?.summary ?? ''
}
