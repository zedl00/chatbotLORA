// Ruta: /src/stores/auth.store.ts
import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { supabase } from '@/services/supabase.client'
import type { User, UserRole } from '@/types/user.types'

interface AuthState {
  user: User | null
  initialized: boolean
  loading: boolean
}

export const useAuthStore = defineStore('auth', () => {
  // ── STATE ──────────────────────────────────────────────
  const user = ref<User | null>(null)
  const initialized = ref(false)
  const loading = ref(false)

  // ── GETTERS ────────────────────────────────────────────
  const isAuthenticated = computed(() => user.value !== null)
  const role = computed<UserRole | null>(() => user.value?.role ?? null)
  const organizationId = computed(() => user.value?.organizationId ?? null)

  // ── ACTIONS ────────────────────────────────────────────

  /**
   * Inicializa el estado leyendo la sesión existente (si la hay).
   * Debe llamarse una sola vez al montar la app.
   */
  async function initialize() {
    if (initialized.value) return
    loading.value = true
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (session?.user) {
        await loadProfile(session.user.id)
      }

      // Escuchar cambios de sesión
      supabase.auth.onAuthStateChange(async (_event, newSession) => {
        if (newSession?.user) {
          await loadProfile(newSession.user.id)
        } else {
          user.value = null
        }
      })
    } finally {
      initialized.value = true
      loading.value = false
    }
  }

  async function loadProfile(authUserId: string) {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', authUserId)
      .maybeSingle()

    if (error) {
      console.error('[auth.store] Error cargando perfil:', error)
      user.value = null
      return
    }

    if (!data) {
      console.warn('[auth.store] Usuario autenticado pero sin perfil en tabla users')
      user.value = null
      return
    }

    user.value = {
      id: data.id,
      organizationId: data.organization_id,
      email: data.email,
      fullName: data.full_name,
      avatarUrl: data.avatar_url,
      phone: data.phone,
      role: data.role,
      active: data.active,
      lastSeenAt: data.last_seen_at,
      preferences: data.preferences ?? {},
      createdAt: data.created_at,
      updatedAt: data.updated_at
    }
  }

  async function signIn(email: string, password: string) {
    loading.value = true
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) throw error
      if (data.user) await loadProfile(data.user.id)
    } finally {
      loading.value = false
    }
  }

  async function signOut() {
    loading.value = true
    try {
      await supabase.auth.signOut()
      user.value = null
    } finally {
      loading.value = false
    }
  }

  async function sendPasswordReset(email: string) {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`
    })
    if (error) throw error
  }

  return {
    // state
    user,
    initialized,
    loading,
    // getters
    isAuthenticated,
    role,
    organizationId,
    // actions
    initialize,
    signIn,
    signOut,
    sendPasswordReset
  }
})
