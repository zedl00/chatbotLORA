// Ruta: /src/router/index.ts
import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import { authGuard, roleGuard } from './guards'

const routes: RouteRecordRaw[] = [
  // ── AUTH ────────────────────────────────────────────
  {
    path: '/auth',
    component: () => import('@/layouts/AuthLayout.vue'),
    children: [
      {
        path: 'login',
        name: 'auth.login',
        component: () => import('@/modules/auth/views/LoginView.vue'),
        meta: { public: true }
      },
      {
        path: 'forgot-password',
        name: 'auth.forgot',
        component: () => import('@/modules/auth/views/ForgotPasswordView.vue'),
        meta: { public: true }
      }
    ]
  },

  // ── ADMIN PANEL ─────────────────────────────────────
  {
    path: '/admin',
    component: () => import('@/layouts/AdminLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      {
        path: '',
        redirect: { name: 'admin.dashboard' }
      },
      {
        path: 'dashboard',
        name: 'admin.dashboard',
        component: () => import('@/modules/reports/views/DashboardView.vue'),
        meta: { roles: ['super_admin', 'admin', 'supervisor'] }
      },
      {
        path: 'inbox',
        name: 'admin.inbox',
        component: () => import('@/modules/inbox/views/InboxView.vue'),
        meta: { roles: ['super_admin', 'admin', 'supervisor', 'agent'] }
      },
      {
        path: 'my-inbox',
        name: 'admin.my-inbox',
        component: () => import('@/modules/inbox/views/MyInboxView.vue'),
        meta: { roles: ['agent', 'supervisor', 'admin', 'super_admin'] }
      },
      {
        path: 'contacts',
        name: 'admin.contacts',
        component: () => import('@/modules/contacts/views/ContactsView.vue'),
        meta: { roles: ['super_admin', 'admin', 'supervisor', 'agent'] }
      },
      {
        path: 'flows',
        name: 'admin.flows',
        component: () => import('@/modules/flows/views/FlowsView.vue'),
        meta: { roles: ['super_admin', 'admin'] }
      },
      {
        path: 'knowledge',
        name: 'admin.knowledge',
        component: () => import('@/modules/knowledge/views/KnowledgeView.vue'),
        meta: { roles: ['super_admin', 'admin'] }
      },
      {
        path: 'channels',
        name: 'admin.channels',
        component: () => import('@/modules/channels/views/ChannelsView.vue'),
        meta: { roles: ['super_admin', 'admin'] }
      },
      {
        path: 'agents',
        name: 'admin.agents',
        component: () => import('@/modules/agents/views/AgentsView.vue'),
        meta: { roles: ['super_admin', 'admin'] }
      },
      {
        path: 'reports',
        name: 'admin.reports',
        component: () => import('@/modules/reports/views/ReportsView.vue'),
        meta: { roles: ['super_admin', 'admin', 'supervisor'] }
      },
      {
        path: 'settings',
        name: 'admin.settings',
        component: () => import('@/modules/settings/views/SettingsView.vue'),
        meta: { roles: ['super_admin', 'admin'] }
      }
    ]
  },

  // ── FALLBACK ────────────────────────────────────────
  { path: '/', redirect: { name: 'admin.dashboard' } },
  { path: '/:pathMatch(.*)*', redirect: { name: 'auth.login' } }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach(authGuard)
router.beforeEach(roleGuard)

export default router
