// Ruta: /src/router/guards.ts
import type { NavigationGuard } from 'vue-router'
import { useAuthStore } from '@/stores/auth.store'
import type { UserRole } from '@/types/user.types'

/**
 * Guard de autenticación: redirige a login si la ruta requiere auth y no hay sesión.
 */
export const authGuard: NavigationGuard = async (to) => {
  const authStore = useAuthStore()

  // Asegurar que la sesión haya sido inicializada
  if (!authStore.initialized) {
    await authStore.initialize()
  }

  const isPublic = to.meta.public === true
  const requiresAuth = to.meta.requiresAuth === true

  if (requiresAuth && !authStore.isAuthenticated) {
    return { name: 'auth.login', query: { redirect: to.fullPath } }
  }

  // Si ya está autenticado y va a login, mandarlo al dashboard
  if (isPublic && authStore.isAuthenticated && to.name === 'auth.login') {
    return { name: 'admin.dashboard' }
  }

  return true
}

/**
 * Guard de roles: verifica que el usuario tenga uno de los roles permitidos.
 * Nota: esta es una validación de UX. La defensa real es RLS en Supabase.
 */
export const roleGuard: NavigationGuard = (to) => {
  const authStore = useAuthStore()
  const allowedRoles = to.meta.roles as UserRole[] | undefined

  if (!allowedRoles || allowedRoles.length === 0) return true

  if (!authStore.user) {
    return { name: 'auth.login' }
  }

  const userRole = authStore.user.role
  if (!allowedRoles.includes(userRole)) {
    return { name: 'admin.dashboard' }
  }

  return true
}
