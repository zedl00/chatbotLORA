// Ruta: /src/utils/format.ts
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import 'dayjs/locale/es'

dayjs.extend(relativeTime)
dayjs.locale('es')

/** Fecha relativa: "hace 5 min", "ayer", "hace 2 días" */
export function timeAgo(date: string | Date | null): string {
  if (!date) return '—'
  return dayjs(date).fromNow()
}

/** Formato corto: "15 abr, 14:30" */
export function formatDateShort(date: string | Date | null): string {
  if (!date) return '—'
  return dayjs(date).format('D MMM, HH:mm')
}

/** Formato completo: "martes 15 de abril, 14:30" */
export function formatDateFull(date: string | Date | null): string {
  if (!date) return '—'
  return dayjs(date).format('dddd D [de] MMMM, HH:mm')
}

/** Duración en segundos → "1h 15m" o "45m" o "30s" */
export function formatDuration(seconds: number | null): string {
  if (seconds === null || seconds === undefined) return '—'
  if (seconds < 60) return `${seconds}s`
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  return m > 0 ? `${h}h ${m}m` : `${h}h`
}

/** Números con separador de miles */
export function formatNumber(n: number): string {
  return new Intl.NumberFormat('es-DO').format(n)
}

/** Trunca con ellipsis */
export function truncate(text: string | null, max = 80): string {
  if (!text) return ''
  return text.length > max ? text.slice(0, max).trimEnd() + '…' : text
}

/** Inicial del nombre para avatar */
export function initials(name: string | null | undefined, fallback = '?'): string {
  if (!name?.trim()) return fallback
  const parts = name.trim().split(/\s+/).slice(0, 2)
  return parts.map((p) => p[0]?.toUpperCase() ?? '').join('')
}
