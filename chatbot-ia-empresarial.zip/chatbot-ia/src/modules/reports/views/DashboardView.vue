<!-- Ruta: /src/modules/reports/views/DashboardView.vue -->
<script setup lang="ts">
import { useAuthStore } from '@/stores/auth.store'
const authStore = useAuthStore()
</script>

<template>
  <div class="p-6 space-y-4">
    <div>
      <h2 class="text-2xl font-bold">Dashboard</h2>
      <p class="text-slate-500">Bienvenido, {{ authStore.user?.fullName || authStore.user?.email }}.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="card p-5">
        <div class="text-sm text-slate-500">Conversaciones activas</div>
        <div class="text-3xl font-bold mt-1">—</div>
      </div>
      <div class="card p-5">
        <div class="text-sm text-slate-500">Agentes en línea</div>
        <div class="text-3xl font-bold mt-1">—</div>
      </div>
      <div class="card p-5">
        <div class="text-sm text-slate-500">Tiempo de espera promedio</div>
        <div class="text-3xl font-bold mt-1">—</div>
      </div>
      <div class="card p-5">
        <div class="text-sm text-slate-500">CSAT promedio</div>
        <div class="text-3xl font-bold mt-1">—</div>
      </div>
    </div>

    <div class="card p-6">
      <div class="text-slate-500 text-sm">
        📌 Los KPIs se conectarán en Sprint 5. Esta vista es un placeholder del Sprint 1.
      </div>
    </div>
  </div>
</template>
